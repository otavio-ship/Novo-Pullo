import secrets
import smtplib
import threading

from email.mime.text import MIMEText

from flask import Flask, Blueprint, jsonify, request
from flask_cors import CORS

from werkzeug.security import generate_password_hash, check_password_hash

import config
import models


app = Flask(__name__)

# Cria as tabelas de operação caso ainda não existam.
try:
    models.preparar_tabelas_operacao()
except Exception as e:
    print("AVISO AO PREPARAR TABELAS:", e)

auth_bp = Blueprint(
    "auth",
    __name__,
    url_prefix="/api"
)

CORS(app)


# =========================================================
# VALIDACOES
# =========================================================

def email_valido(email):

    return "@" in email and "." in email


def senha_valida(senha):

    return len(senha) >= 6


# =========================================================
# EMAIL
# =========================================================

def enviar_email(destinatario, assunto, corpo):

    try:

        mensagem = MIMEText(
            corpo,
            "plain",
            "utf-8"
        )

        mensagem["Subject"] = assunto
        mensagem["From"] = config.SMTP_EMAIL
        mensagem["To"] = destinatario

        servidor = smtplib.SMTP(
            config.SMTP_HOST,
            config.SMTP_PORT,
            timeout=10
        )

        servidor.ehlo()

        servidor.starttls()

        servidor.ehlo()

        servidor.login(
            config.SMTP_EMAIL,
            config.SMTP_SENHA.replace(" ", "")
        )

        servidor.sendmail(
            config.SMTP_EMAIL,
            [destinatario],
            mensagem.as_string()
        )

        servidor.quit()

        print("EMAIL ENVIADO COM SUCESSO")

        return True

    except Exception as e:

        print(
            "ERRO AO ENVIAR EMAIL:",
            str(e)
        )

        return False


# =========================================================
# ENVIO DE EMAIL EM SEGUNDO PLANO
# =========================================================

def enviar_email_background(
    destinatario,
    assunto,
    corpo
):

    thread = threading.Thread(
        target=enviar_email,
        args=(
            destinatario,
            assunto,
            corpo
        )
    )

    thread.daemon = True

    thread.start()


# =========================================================
# CADASTRO
# =========================================================

@auth_bp.route(
    "/cadastro",
    methods=["POST"]
)
def cadastro():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        nome = str(data.get("nome") or "").strip()
        email = str(data.get("email") or "").strip().lower()
        telefone = "".join(ch for ch in str(data.get("telefone") or "") if ch.isdigit())[:11]
        senha = str(data.get("senha") or "")
        tipo = str(data.get("tipo") or "").strip().upper()

        # =====================================================
        # CAMPOS OBRIGATORIOS
        # =====================================================

        if not nome or not email or not senha or not tipo:

            return jsonify({
                "error":
                "Nome, email, senha e tipo sao obrigatorios"
            }), 400

        # =====================================================
        # TIPO DO USUARIO
        # =====================================================

        if tipo not in [
            "CLIENTE",
            "ENTREGADOR",
            "ADM"
        ]:

            return jsonify({
                "error":
                "Tipo de usuario invalido"
            }), 400

        # =====================================================
        # NOME E TELEFONE
        # =====================================================

        if len(nome) < 3:
            return jsonify({"error": "Nome deve ter pelo menos 3 caracteres"}), 400

        if telefone and len(telefone) not in [10, 11]:
            return jsonify({"error": "Telefone deve ter 10 ou 11 numeros"}), 400

        # =====================================================
        # EMAIL
        # =====================================================

        if not email_valido(email):

            return jsonify({
                "error":
                "Email invalido"
            }), 400

        # =====================================================
        # SENHA
        # =====================================================

        if not senha_valida(senha):

            return jsonify({
                "error":
                "Senha deve ter no minimo 6 caracteres"
            }), 400

        # =====================================================
        # PROCURA USUARIO
        # =====================================================

        usuario_existente = (
            models.buscar_usuario_por_email(email)
        )

        # =====================================================
        # EMAIL JA EXISTE
        # =====================================================

        if usuario_existente:

            id_usuario = usuario_existente[0]

            confirmado = usuario_existente[7]

            # =================================================
            # USUARIO JA CONFIRMADO
            # =================================================

            if confirmado:

                return jsonify({
                    "error":
                    "Email ja cadastrado"
                }), 400

            # =================================================
            # USUARIO EXISTE MAS NAO CONFIRMOU
            # =================================================

            codigo = (
                f"{secrets.randbelow(1000000):06d}"
            )

            models.criar_codigo(
                id_usuario,
                codigo,
                "CONFIRMACAO"
            )

            # =================================================
            # ENVIA EMAIL SEM TRAVAR O CADASTRO
            # =================================================

            enviar_email(
                email,
                "Confirmacao de cadastro",
                f"Seu codigo de confirmacao e: {codigo}"
            )

            print(
                "CODIGO GERADO:",
                codigo
            )

            return jsonify({
                "message":
                "Cadastro pendente. Novo codigo enviado.",
                "precisa_confirmar": True
            }), 200

        # =====================================================
        # NOVO USUARIO
        # =====================================================

        senha_hash = generate_password_hash(
            senha
        )

        id_usuario = models.criar_usuario(
            nome,
            email,
            senha_hash,
            telefone,
            tipo
        )

        # =====================================================
        # GERA CODIGO
        # =====================================================

        codigo = (
            f"{secrets.randbelow(1000000):06d}"
        )

        # =====================================================
        # SALVA CODIGO NO BANCO
        # =====================================================

        models.criar_codigo(
            id_usuario,
            codigo,
            "CONFIRMACAO"
        )

        # =====================================================
        # ENVIA CODIGO POR EMAIL
        # =====================================================

        enviar_email(
            email,
            "Confirmacao de cadastro",
            f"Seu codigo de confirmacao e: {codigo}"
        )

        print(
            "CODIGO GERADO:",
            codigo
        )

        # =====================================================
        # RESPOSTA IMEDIATA
        # =====================================================

        return jsonify({
            "message":
            "Usuario cadastrado com sucesso",
            "precisa_confirmar": True
        }), 201

    except Exception as e:

        print(
            "ERRO NO CADASTRO:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# CONFIRMAR CADASTRO
# =========================================================

@auth_bp.route(
    "/verificar_codigo",
    methods=["POST"]
)
def verificar_codigo():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = data.get("email")
        codigo = data.get("codigo")

        if not email or not codigo:

            return jsonify({
                "error":
                "Email e codigo sao obrigatorios"
            }), 400

        confirmado = models.confirmar_codigo(
            email,
            codigo
        )

        if not confirmado:

            return jsonify({
                "error":
                "Código incorreto."
            }), 400

        return jsonify({
            "message":
            "Cadastro confirmado com sucesso"
        }), 200

    except Exception as e:

        print(
            "ERRO AO CONFIRMAR CADASTRO:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# LOGIN
# =========================================================

@auth_bp.route(
    "/login",
    methods=["POST"]
)
def login():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = str(data.get("email") or "").strip().lower()
        senha = str(data.get("senha") or "")

        if not email or not senha:

            return jsonify({
                "error":
                "Email e senha sao obrigatorios"
            }), 400

        usuario = (
            models.buscar_usuario_por_email(email)
        )

        if not usuario:

            return jsonify({
                "error":
                "Email ou senha incorretos"
            }), 401

        (
            id_usuario,
            nome,
            email_db,
            senha_hash,
            tipo,
            tentativas,
            bloqueado,
            confirmado
        ) = usuario

        # =====================================================
        # BLOQUEADO
        # =====================================================

        if bloqueado:

            return jsonify({
                "error":
                "Usuario bloqueado por excesso de tentativas"
            }), 403

        # =====================================================
        # PRECISA CONFIRMAR
        # =====================================================

        if not confirmado:

            return jsonify({
                "error":
                "Confirme seu cadastro antes de fazer login",
                "precisa_confirmar": True
            }), 403

        # =====================================================
        # SENHA INCORRETA
        # =====================================================

        if not check_password_hash(
            senha_hash,
            senha
        ):

            models.registrar_tentativa_errada(
                id_usuario,
                tentativas
            )

            tentativas_restantes = (
                config.MAX_TENTATIVAS_LOGIN
                - (tentativas + 1)
            )

            if tentativas_restantes <= 0:

                return jsonify({
                    "error":
                    "Usuario bloqueado por excesso de tentativas"
                }), 403

            return jsonify({
                "error":
                "Email ou senha incorretos",
                "tentativas_restantes":
                tentativas_restantes
            }), 401

        # =====================================================
        # LOGIN CORRETO
        # =====================================================

        models.zerar_tentativas(
            id_usuario
        )

        perfil = models.buscar_usuario_por_id(id_usuario)
        telefone = perfil[3] if perfil else ""

        return jsonify({
            "message":
            "Login realizado com sucesso",

            "usuario": {
                "id": id_usuario,
                "nome": nome,
                "email": email_db,
                "telefone": telefone or "",
                "tipo": tipo
            }

        }), 200

    except Exception as e:

        print(
            "ERRO NO LOGIN:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# EDITAR PERFIL
# =========================================================

@auth_bp.route("/editar_perfil", methods=["PUT"])
def editar_perfil():
    try:
        data = request.get_json(silent=True) or {}
        id_usuario = data.get("id")
        nome = str(data.get("nome") or "").strip()
        telefone = "".join(ch for ch in str(data.get("telefone") or "") if ch.isdigit())[:11]
        senha_atual = str(data.get("senha_atual") or "")
        nova_senha = str(data.get("nova_senha") or "")

        if not id_usuario:
            return jsonify({"error": "Usuário não identificado"}), 400
        if len(nome) < 3:
            return jsonify({"error": "Digite seu nome completo"}), 400
        if telefone and len(telefone) not in [10, 11]:
            return jsonify({"error": "Telefone deve ter 10 ou 11 números"}), 400

        usuario = models.buscar_usuario_por_id(id_usuario)
        if not usuario:
            return jsonify({"error": "Usuário não encontrado"}), 404

        # O índice 3 é o telefone nesta consulta. A senha é buscada separadamente.
        usuario_email = usuario[2]
        usuario_login = models.buscar_usuario_por_email(usuario_email)
        if not usuario_login:
            return jsonify({"error": "Usuário não encontrado"}), 404

        if nova_senha:
            if len(nova_senha) < 6:
                return jsonify({"error": "A nova senha deve ter pelo menos 6 caracteres"}), 400
            if not senha_atual:
                return jsonify({"error": "Digite sua senha atual para alterar a senha"}), 400
            if not check_password_hash(usuario_login[3], senha_atual):
                return jsonify({"error": "A senha atual está incorreta"}), 400
            if models.senha_ja_usada(id_usuario, nova_senha):
                return jsonify({"error": "A nova senha não pode ser igual às últimas 3 senhas"}), 400
            models.atualizar_perfil(id_usuario, nome, telefone)
            models.atualizar_senha(id_usuario, generate_password_hash(nova_senha))
        else:
            models.atualizar_perfil(id_usuario, nome, telefone)

        atualizado = models.buscar_usuario_por_id(id_usuario)
        return jsonify({
            "message": "Perfil atualizado com sucesso",
            "usuario": {
                "id": atualizado[0],
                "nome": atualizado[1],
                "email": atualizado[2],
                "telefone": atualizado[3] or "",
                "tipo": atualizado[4]
            }
        }), 200

    except Exception as e:
        print("ERRO AO EDITAR PERFIL:", str(e))
        return jsonify({"error": str(e)}), 500


# =========================================================
# ALTERAR SENHA APÓS RECUPERAÇÃO
# =========================================================

@auth_bp.route("/alterar_senha", methods=["POST"])
def alterar_senha():
    try:
        data = request.get_json(silent=True) or {}
        email = str(data.get("email") or "").strip().lower()
        nova_senha = str(data.get("nova_senha") or "")
        confirmar_senha = str(data.get("confirmar_senha") or "")

        if not email or not nova_senha or not confirmar_senha:
            return jsonify({"error": "Preencha todos os campos"}), 400
        if nova_senha != confirmar_senha:
            return jsonify({"error": "As senhas não são iguais"}), 400
        if len(nova_senha) < 6:
            return jsonify({"error": "A senha deve ter pelo menos 6 caracteres"}), 400

        usuario = models.buscar_usuario_por_email(email)
        if not usuario:
            return jsonify({"error": "E-mail não encontrado"}), 404

        id_usuario = usuario[0]
        if not models.recuperacao_confirmada(id_usuario):
            return jsonify({"error": "Confirme o código de recuperação antes de criar uma nova senha"}), 400
        if models.senha_ja_usada(id_usuario, nova_senha):
            return jsonify({"error": "A nova senha não pode ser igual às últimas 3 senhas"}), 400

        models.alterar_senha_recuperacao(id_usuario, generate_password_hash(nova_senha))
        return jsonify({"message": "Senha alterada com sucesso"}), 200

    except Exception as e:
        print("ERRO AO ALTERAR SENHA:", str(e))
        return jsonify({"error": str(e)}), 500


# =========================================================
# ESQUECEU SENHA
# =========================================================

@auth_bp.route(
    "/esqueceu_senha",
    methods=["POST"]
)
def esqueceu_senha():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = data.get("email")

        if not email:

            return jsonify({
                "error":
                "Email e obrigatorio"
            }), 400

        usuario = (
            models.buscar_usuario_por_email(email)
        )

        if not usuario:

            return jsonify({
                "error":
                "Usuario nao encontrado"
            }), 404

        id_usuario = usuario[0]

        codigo = (
            f"{secrets.randbelow(1000000):06d}"
        )

        models.criar_codigo(
            id_usuario,
            codigo,
            "RECUPERACAO"
        )

        # =====================================================
        # ENVIA EMAIL SEM TRAVAR
        # =====================================================

        enviar_email(
            email,
            "Recuperacao de senha",
            f"Seu codigo de recuperacao e: {codigo}"
        )

        print(
            "CODIGO DE RECUPERACAO:",
            codigo
        )

        return jsonify({
            "message":
            "Codigo de recuperacao enviado"
        }), 200

    except Exception as e:

        print(
            "ERRO NA RECUPERACAO:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# CONFIRMAR CODIGO DE RECUPERACAO
# =========================================================

@auth_bp.route(
    "/confirmar_codigo_recuperacao",
    methods=["POST"]
)
def confirmar_codigo_recuperacao():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = data.get("email")
        codigo = data.get("codigo")

        if not email or not codigo:

            return jsonify({
                "error":
                "Email e codigo sao obrigatorios"
            }), 400

        # =====================================================
        # BUSCAR USUARIO
        # =====================================================

        usuario = models.buscar_usuario_por_email(
            email
        )

        if not usuario:

            return jsonify({
                "error":
                "Usuario nao encontrado"
            }), 404

        id_usuario = usuario[0]

        # =====================================================
        # CODIGO FIXO PARA TESTE
        # =====================================================

        if str(codigo) == "123456":

            con = models.conectar()
            cursor = con.cursor()

            # Procura um código de recuperação existente
            cursor.execute("""
                SELECT ID_CODIGO
                FROM CODIGOS
                WHERE ID_USUARIO = ?
                AND TIPO = 'RECUPERACAO'
                AND UTILIZADO = 0
            """, (
                id_usuario,
            ))

            resultado = cursor.fetchone()

            if resultado:

                id_codigo = resultado[0]

                cursor.execute("""
                    UPDATE CODIGOS
                    SET
                        CODIGO = '123456',
                        CONFIRMADO = 1
                    WHERE ID_CODIGO = ?
                """, (
                    id_codigo,
                ))

            else:

                cursor.execute("""
                    INSERT INTO CODIGOS (
                        ID_USUARIO,
                        CODIGO,
                        TIPO,
                        UTILIZADO,
                        CONFIRMADO
                    )
                    VALUES (?, '123456', 'RECUPERACAO', 0, 1)
                """, (
                    id_usuario,
                ))

            con.commit()
            con.close()

            return jsonify({
                "message":
                "Codigo confirmado com sucesso"
            }), 200

        # =====================================================
        # CODIGO NORMAL
        # =====================================================

        resultado = models.confirmar_codigo_recuperacao(
            email,
            codigo
        )

        if not resultado:

            return jsonify({
                "error":
                "Codigo de recuperacao invalido"
            }), 400

        return jsonify({
            "message":
            "Codigo confirmado com sucesso"
        }), 200

    except Exception as e:

        print(
            "ERRO AO CONFIRMAR CODIGO:",
            str(e)
        )

        return jsonify({
            "error":
            str(e)
        }), 500

# =========================================================
# ALTERAR SENHA
# =========================================================

@auth_bp.route(
    "/recuperar_senha",
    methods=["POST"]
)
def recuperar_senha():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = data.get("email")

        if not email:

            return jsonify({
                "error":
                "Digite o e-mail."
            }), 400

        usuario = models.buscar_usuario_por_email(
            email
        )

        if not usuario:

            return jsonify({
                "error":
                "E-mail não encontrado."
            }), 404

        id_usuario = usuario[0]

        # Código fixo para os testes
        codigo = "123456"

        models.criar_codigo_recuperacao(
            id_usuario,
            codigo
        )

        return jsonify({
            "message":
            "Código enviado com sucesso"
        }), 200

    except Exception as e:

        print(
            "ERRO AO RECUPERAR SENHA:",
            str(e)
        )

        return jsonify({
            "error":
            str(e)
        }), 500


@auth_bp.route("/alterar_senha", methods=["POST"])
def alterar_senha_api():
    try:
        data=request.get_json(silent=True) or {}
        email=data.get("email"); nova=data.get("nova_senha"); confirmar=data.get("confirmar_senha")
        if not email or not nova or not confirmar: return jsonify({"error":"Preencha todos os campos."}),400
        if nova != confirmar: return jsonify({"error":"As senhas nao sao iguais."}),400
        if not senha_valida(nova): return jsonify({"error":"Senha deve ter no minimo 6 caracteres"}),400
        usuario=models.buscar_usuario_por_email(email)
        if not usuario: return jsonify({"error":"E-mail nao encontrado."}),404
        id_usuario=usuario[0]
        if not models.recuperacao_confirmada(id_usuario): return jsonify({"error":"Confirme o codigo de recuperacao primeiro."}),403
        if models.senha_ja_usada(id_usuario,nova): return jsonify({"error":"A nova senha nao pode ser uma das ultimas 3 senhas."}),400
        models.alterar_senha_recuperacao(id_usuario,generate_password_hash(nova))
        return jsonify({"message":"Senha alterada com sucesso"}),200
    except Exception as e: return jsonify({"error":str(e)}),500

# =========================================================
# PEDIDOS / ENTREGAS / ADMINISTRACAO
# =========================================================

# =========================================================
# PEDIDOS
# =========================================================

@auth_bp.route("/pedidos", methods=["GET", "POST"])
def pedidos_api():

    try:

        # =====================================================
        # LISTAR PEDIDOS
        # =====================================================

        if request.method == "GET":

            id_cliente = request.args.get(
                "id_cliente",
                type=int
            )

            rows = models.listar_pedidos(id_cliente)

            pedidos = []

            for r in rows:

                pedidos.append({
                    "id": r[0],
                    "cliente_id": r[1],
                    "supermercado_id": r[2],
                    "supermercado": r[3],
                    "numero": r[4],
                    "endereco": r[5],
                    "horario": r[6],
                    "status": r[7]
                })

            return jsonify({
                "pedidos": pedidos
            }), 200





        # =====================================================
        # CADASTRAR PEDIDO
        # =====================================================

        data = request.get_json(
            silent=True
        ) or {}

        id_cliente = data.get("id_cliente")

        supermercado = str(
            data.get("supermercado") or ""
        ).strip()

        numero = str(
            data.get("numero") or ""
        ).strip()

        endereco = str(
            data.get("endereco") or ""
        ).strip()

        horario = str(
            data.get("horario") or ""
        ).strip()

        # =====================================================
        # VALIDAÇÕES
        # =====================================================

        if not id_cliente:
            return jsonify({
                "error": "Cliente não informado"
            }), 400

        if not supermercado:
            return jsonify({
                "error": "Informe o supermercado"
            }), 400

        if not numero:
            return jsonify({
                "error": "Informe o número do pedido"
            }), 400

        if not endereco:
            return jsonify({
                "error": "Informe o endereço de entrega"
            }), 400

        # =====================================================
        # PROCURA O SUPERMERCADO
        # =====================================================

        con = models.conectar()
        cursor = con.cursor()

        cursor.execute("""
            SELECT ID_SUPERMERCADO
            FROM SUPERMERCADOS
            WHERE UPPER(NOME) = UPPER(?)
        """, (
            supermercado,
        ))

        supermercado_db = cursor.fetchone()

        if not supermercado_db:

            cursor.close()
            con.close()

            return jsonify({
                "error": "Supermercado não encontrado"
            }), 404

        id_supermercado = supermercado_db[0]

        cursor.close()
        con.close()

        # =====================================================
        # CRIA O PEDIDO
        # =====================================================



        id_pedido = models.criar_pedido(
            id_cliente,
            id_supermercado,
            numero,
            endereco,
            horario
        )

        return jsonify({
            "message": "Pedido criado com sucesso",
            "id": id_pedido
        }), 201

    except Exception as e:

        print(
            "ERRO AO CADASTRAR/LISTAR PEDIDO:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500

@auth_bp.route("/entregas", methods=["GET"])
def entregas_api():
    try:
        id_entregador=request.args.get("id_entregador", type=int)
        disponiveis=request.args.get("disponiveis","0") == "1"
        rows=models.listar_entregas(id_entregador,disponiveis)
        return jsonify({"entregas":[{"id":r[0],"supermercados":r[1],"numero":r[2],"endereco":r[3],"valor":float(r[4] or 0),"status":r[5],"entregador_id":r[6],"cliente_id":r[7]} for r in rows]}),200
    except Exception as e:return jsonify({"error":str(e)}),500

@auth_bp.route("/entregas/aceitar", methods=["POST"])
def aceitar_entrega_api():
    try:
        data=request.get_json(silent=True) or {}
        if not models.aceitar_pedido(int(data.get("id_pedido")),int(data.get("id_entregador"))):
            return jsonify({"error":"Pedido ja foi aceito por outro entregador."}),409
        return jsonify({"message":"Entrega aceita com sucesso"}),200
    except Exception as e:return jsonify({"error":str(e)}),500

@auth_bp.route("/entregas/status", methods=["PUT"])
def status_entrega_api():
    try:
        data=request.get_json(silent=True) or {}
        ok=models.atualizar_status_pedido(int(data.get("id_pedido")),data.get("status"),data.get("id_entregador"))
        return (jsonify({"message":"Status atualizado"}),200) if ok else (jsonify({"error":"Pedido nao encontrado"}),404)
    except Exception as e:return jsonify({"error":str(e)}),500

@auth_bp.route("/admin/usuarios", methods=["GET"])
def admin_usuarios():
    try:
        rows=models.listar_usuarios_admin()
        return jsonify({"usuarios":[{"id":r[0],"nome":r[1],"email":r[2],"telefone":r[3] or "","tipo":r[4],"confirmado":bool(r[5]),"bloqueado":bool(r[6])} for r in rows]}),200
    except Exception as e:return jsonify({"error":str(e)}),500

@auth_bp.route("/admin/usuarios/<int:id_usuario>", methods=["PUT","DELETE"])
def admin_usuario(id_usuario):
    try:
        if request.method=="DELETE":
            models.excluir_usuario_admin(id_usuario)
            return jsonify({"message":"Usuario excluido"}),200
        data=request.get_json(silent=True) or {}
        tipo=data.get("tipo","CLIENTE")
        if tipo not in ["CLIENTE","ENTREGADOR","ADM"]: return jsonify({"error":"Tipo invalido"}),400
        models.editar_usuario_admin(id_usuario,data.get("nome",""),data.get("telefone",""),tipo,1 if data.get("bloqueado") else 0)
        return jsonify({"message":"Usuario atualizado"}),200
    except Exception as e:return jsonify({"error":str(e)}),500

@auth_bp.route("/avaliacoes", methods=["GET", "POST"])
def avaliacoes_api():
    try:
        if request.method == "GET":
            id_cliente=request.args.get("id_cliente", type=int)
            id_pedido=request.args.get("id_pedido", type=int)
            if id_pedido:
                row=models.buscar_avaliacao_pedido(id_pedido, id_cliente)
                if not row:
                    return jsonify({"avaliacao":None}),200
                return jsonify({"avaliacao":{"id":row[0],"pedido_id":row[1],"cliente_id":row[2],"entregador_id":row[3],"nota":row[4],"comentario":row[5] or "","data":str(row[6]) if row[6] else ""}}),200
            return jsonify({"avaliacoes":[]}),200
        data=request.get_json(silent=True) or {}
        id_pedido=int(data.get("id_pedido")); id_cliente=int(data.get("id_cliente")); nota=int(data.get("nota"))
        if nota < 1 or nota > 5:
            return jsonify({"error":"A nota deve ser de 1 a 5 estrelas."}),400
        ok,result=models.criar_avaliacao(id_pedido,id_cliente,nota,data.get("comentario",""))
        if not ok:
            return jsonify({"error":result}),400
        return jsonify({"message":"Avaliação registrada com sucesso","id":result}),201
    except Exception as e:
        return jsonify({"error":str(e)}),500

@auth_bp.route("/admin/avaliacoes", methods=["GET"])
def admin_avaliacoes():
    try:
        rows=models.listar_avaliacoes_admin()
        return jsonify({"avaliacoes":[{"id":r[0],"pedido_id":r[1],"cliente_id":r[2],"entregador_id":r[3],"nota":r[4],"comentario":r[5] or "","data":str(r[6]) if r[6] else "","cliente":r[7] or "","entregador":r[8] or ""} for r in rows]}),200
    except Exception as e:
        return jsonify({"error":str(e)}),500

@auth_bp.route("/admin/pedidos", methods=["GET"])
def admin_pedidos():
    try:
        rows=models.listar_pedidos()
        return jsonify({"pedidos":[{"id":r[0],"cliente_id":r[1],"entregador_id":r[2],"supermercados":r[3],"numero":r[4],"endereco":r[5],"valor":float(r[6] or 0),"status":r[7],"data":str(r[8]) if r[8] else "","entregador":r[9] or ""} for r in rows]}),200
    except Exception as e:return jsonify({"error":str(e)}),500

# =========================================================
# REGISTRAR BLUEPRINT
# =========================================================

app.register_blueprint(
    auth_bp
)


# =========================================================
# INICIAR SERVIDOR
# =========================================================

if __name__ == "__main__":

    app.run(
        debug=True,
        port=5000
    )
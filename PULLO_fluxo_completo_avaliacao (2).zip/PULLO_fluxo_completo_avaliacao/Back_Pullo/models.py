import fdb
from werkzeug.security import check_password_hash

import config


def conectar():
    return fdb.connect(
        dsn=config.FIREBIRD_DSN,
        user=config.FIREBIRD_USER,
        password=config.FIREBIRD_PASSWORD,
        charset="UTF8"
    )


# =========================================================
# BUSCAR USUARIO
# =========================================================

def buscar_usuario_por_email(email):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            ID_USUARIO,
            NOME,
            EMAIL,
            SENHA,
            TIPO,
            TENTATIVAS_LOGIN,
            BLOQUEADO,
            CONFIRMADO
        FROM USUARIOS
        WHERE EMAIL = ?
    """, (email,))

    usuario = cursor.fetchone()

    con.close()

    return usuario


def buscar_usuario_por_id(id_usuario):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            ID_USUARIO,
            NOME,
            EMAIL,
            TELEFONE,
            TIPO,
            CONFIRMADO
        FROM USUARIOS
        WHERE ID_USUARIO = ?
    """, (id_usuario,))

    usuario = cursor.fetchone()

    con.close()

    return usuario


# =========================================================
# ATUALIZAR PERFIL
# =========================================================

def atualizar_perfil(id_usuario, nome, telefone):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        UPDATE USUARIOS
        SET NOME = ?, TELEFONE = ?
        WHERE ID_USUARIO = ?
    """, (nome, telefone, id_usuario))

    con.commit()
    con.close()


def atualizar_senha(id_usuario, senha_hash):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT SENHA
        FROM USUARIOS
        WHERE ID_USUARIO = ?
    """, (id_usuario,))

    senha_antiga = cursor.fetchone()

    if senha_antiga:
        cursor.execute("""
            INSERT INTO SENHAS_HISTORICO (ID_USUARIO, SENHA)
            VALUES (?, ?)
        """, (id_usuario, senha_antiga[0]))

    cursor.execute("""
        UPDATE USUARIOS
        SET SENHA = ?, TENTATIVAS_LOGIN = 0, BLOQUEADO = 0
        WHERE ID_USUARIO = ?
    """, (senha_hash, id_usuario))

    con.commit()
    con.close()


# =========================================================
# CRIAR USUARIO
# =========================================================

def criar_usuario(nome, email, senha_hash, telefone, tipo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        INSERT INTO USUARIOS (
            NOME,
            EMAIL,
            SENHA,
            TELEFONE,
            TIPO,
            TENTATIVAS_LOGIN,
            BLOQUEADO,
            CONFIRMADO
        )
        VALUES (?, ?, ?, ?, ?, 0, 0, 0)
        RETURNING ID_USUARIO
    """, (
        nome,
        email,
        senha_hash,
        telefone,
        tipo
    ))

    id_usuario = cursor.fetchone()[0]

    con.commit()
    con.close()

    return id_usuario


# =========================================================
# CRIAR CODIGO
# =========================================================

def criar_codigo(id_usuario, codigo, tipo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        INSERT INTO CODIGOS (
            ID_USUARIO,
            CODIGO,
            TIPO,
            UTILIZADO,
            CONFIRMADO
        )
        VALUES (?, ?, ?, 0, 0)
    """, (
        id_usuario,
        codigo,
        tipo
    ))

    con.commit()
    con.close()


# =========================================================
# CONFIRMAR CADASTRO
# =========================================================

def confirmar_codigo(email, codigo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            c.ID_CODIGO,
            u.ID_USUARIO
        FROM CODIGOS c
        JOIN USUARIOS u
            ON u.ID_USUARIO = c.ID_USUARIO
        WHERE u.EMAIL = ?
        AND c.CODIGO = ?
        AND c.TIPO = 'CONFIRMACAO'
        AND c.UTILIZADO = 0
    """, (
        email,
        codigo
    ))

    resultado = cursor.fetchone()

    if not resultado:
        con.close()
        return False

    id_codigo = resultado[0]
    id_usuario = resultado[1]

    cursor.execute("""
        UPDATE USUARIOS
        SET CONFIRMADO = 1
        WHERE ID_USUARIO = ?
    """, (
        id_usuario,
    ))

    cursor.execute("""
        UPDATE CODIGOS
        SET UTILIZADO = 1
        WHERE ID_CODIGO = ?
    """, (
        id_codigo,
    ))

    con.commit()
    con.close()

    return True


# =========================================================
# LOGIN
# =========================================================

def zerar_tentativas(id_usuario):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        UPDATE USUARIOS
        SET TENTATIVAS_LOGIN = 0
        WHERE ID_USUARIO = ?
    """, (
        id_usuario,
    ))

    con.commit()
    con.close()


def registrar_tentativa_errada(id_usuario, tentativas_atuais):
    novas_tentativas = tentativas_atuais + 1

    bloquear = 0

    if novas_tentativas >= config.MAX_TENTATIVAS_LOGIN:
        bloquear = 1

    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        UPDATE USUARIOS
        SET
            TENTATIVAS_LOGIN = ?,
            BLOQUEADO = ?
        WHERE ID_USUARIO = ?
    """, (
        novas_tentativas,
        bloquear,
        id_usuario
    ))

    con.commit()
    con.close()


# =========================================================
# CRIAR CODIGO DE RECUPERACAO
# =========================================================

def criar_codigo_recuperacao(id_usuario, codigo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        INSERT INTO CODIGOS (
            ID_USUARIO,
            CODIGO,
            TIPO,
            UTILIZADO,
            CONFIRMADO
        )
        VALUES (?, ?, 'RECUPERACAO', 0, 0)
    """, (
        id_usuario,
        codigo
    ))

    con.commit()
    con.close()


# =========================================================
# CONFIRMAR CODIGO DE RECUPERACAO
# =========================================================

def confirmar_codigo_recuperacao(email, codigo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            c.ID_CODIGO
        FROM CODIGOS c
        JOIN USUARIOS u
            ON u.ID_USUARIO = c.ID_USUARIO
        WHERE u.EMAIL = ?
        AND c.CODIGO = ?
        AND c.TIPO = 'RECUPERACAO'
        AND c.UTILIZADO = 0
        AND c.CONFIRMADO = 0
    """, (
        email,
        codigo
    ))

    resultado = cursor.fetchone()

    if not resultado:
        con.close()
        return False

    id_codigo = resultado[0]

    cursor.execute("""
        UPDATE CODIGOS
        SET CONFIRMADO = 1
        WHERE ID_CODIGO = ?
    """, (
        id_codigo,
    ))

    con.commit()
    con.close()

    return True


# =========================================================
# VERIFICAR SE RECUPERACAO FOI CONFIRMADA
# =========================================================

def recuperacao_confirmada(id_usuario):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT ID_CODIGO
        FROM CODIGOS
        WHERE ID_USUARIO = ?
        AND TIPO = 'RECUPERACAO'
        AND CONFIRMADO = 1
        AND UTILIZADO = 0
    """, (
        id_usuario,
    ))

    resultado = cursor.fetchone()

    con.close()

    return resultado is not None


# =========================================================
# VERIFICAR SENHA ATUAL
# =========================================================

def senha_ja_usada(id_usuario, nova_senha):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT SENHA
        FROM USUARIOS
        WHERE ID_USUARIO = ?
    """, (id_usuario,))

    linhas = cursor.fetchall()

    cursor.execute("""
        SELECT SENHA
        FROM SENHAS_HISTORICO
        WHERE ID_USUARIO = ?
        ORDER BY DATA_ALTERACAO DESC
        ROWS 2
    """, (id_usuario,))

    linhas += cursor.fetchall()
    con.close()

    for linha in linhas:
        if check_password_hash(linha[0], nova_senha):
            return True

    return False


# =========================================================
# ALTERAR SENHA
# =========================================================

def alterar_senha_recuperacao(id_usuario, senha_hash):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT SENHA
        FROM USUARIOS
        WHERE ID_USUARIO = ?
    """, (id_usuario,))

    senha_antiga = cursor.fetchone()

    if senha_antiga:
        cursor.execute("""
            INSERT INTO SENHAS_HISTORICO (ID_USUARIO, SENHA)
            VALUES (?, ?)
        """, (id_usuario, senha_antiga[0]))

    cursor.execute("""
        UPDATE USUARIOS
        SET
            SENHA = ?,
            TENTATIVAS_LOGIN = 0,
            BLOQUEADO = 0
        WHERE ID_USUARIO = ?
    """, (
        senha_hash,
        id_usuario
    ))

    cursor.execute("""
        UPDATE CODIGOS
        SET UTILIZADO = 1
        WHERE ID_USUARIO = ?
        AND TIPO = 'RECUPERACAO'
        AND CONFIRMADO = 1
        AND UTILIZADO = 0
    """, (
        id_usuario,
    ))

    con.commit()
    con.close()

    return True
# =========================================================
# PULLO - PEDIDOS E ENTREGAS
# =========================================================

def preparar_tabelas_operacao():
    con = conectar()
    cur = con.cursor()
    try:
        cur.execute("""
            CREATE TABLE PEDIDOS (
                ID_PEDIDO INTEGER NOT NULL,
                ID_CLIENTE INTEGER,
                ID_ENTREGADOR INTEGER,
                SUPERMERCADO VARCHAR(100),
                NUMERO_PEDIDO VARCHAR(30),
                ENDERECO VARCHAR(200),
                VALOR DECIMAL(10,2),
                STATUS VARCHAR(30),
                DATA_CRIACAO TIMESTAMP,
                CONSTRAINT PK_PEDIDOS_PULLO PRIMARY KEY (ID_PEDIDO)
            )
        """)
        con.commit()
    except Exception:
        con.rollback()
    try:
        cur.execute("""
            CREATE TABLE ENTREGAS (
                ID_ENTREGA INTEGER NOT NULL,
                ID_PEDIDO INTEGER NOT NULL,
                ID_ENTREGADOR INTEGER,
                STATUS VARCHAR(30),
                DATA_ATUALIZACAO TIMESTAMP,
                CONSTRAINT PK_ENTREGAS_PULLO PRIMARY KEY (ID_ENTREGA)
            )
        """)
        con.commit()
    except Exception:
        con.rollback()
    try:
        cur.execute("""
            CREATE TABLE AVALIACOES (
                ID_AVALIACAO INTEGER NOT NULL,
                ID_PEDIDO INTEGER NOT NULL,
                ID_CLIENTE INTEGER NOT NULL,
                ID_ENTREGADOR INTEGER,
                NOTA INTEGER NOT NULL,
                COMENTARIO VARCHAR(500),
                DATA_AVALIACAO TIMESTAMP,
                CONSTRAINT PK_AVALIACOES_PULLO PRIMARY KEY (ID_AVALIACAO),
                CONSTRAINT UQ_AVALIACAO_PEDIDO_PULLO UNIQUE (ID_PEDIDO)
            )
        """)
        con.commit()
    except Exception:
        con.rollback()
    con.close()


def _proximo_id(cur, tabela, campo):
    cur.execute(f"SELECT COALESCE(MAX({campo}), 0) + 1 FROM {tabela}")
    return cur.fetchone()[0]


def listar_usuarios_admin():
    con = conectar(); cur = con.cursor()
    cur.execute("""
        SELECT ID_USUARIO, NOME, EMAIL, TELEFONE, TIPO, CONFIRMADO, BLOQUEADO
        FROM USUARIOS ORDER BY ID_USUARIO DESC
    """)
    rows = cur.fetchall(); con.close()
    return rows


def editar_usuario_admin(id_usuario, nome, telefone, tipo, bloqueado):
    con = conectar(); cur = con.cursor()
    cur.execute("""
        UPDATE USUARIOS SET NOME=?, TELEFONE=?, TIPO=?, BLOQUEADO=?
        WHERE ID_USUARIO=?
    """, (nome, telefone, tipo, bloqueado, id_usuario))
    con.commit(); con.close()


def excluir_usuario_admin(id_usuario):
    con = conectar(); cur = con.cursor()
    cur.execute("DELETE FROM USUARIOS WHERE ID_USUARIO=?", (id_usuario,))
    con.commit(); con.close()


def criar_pedido(id_cliente, id_supermercado, numero, endereco, horario):

    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        INSERT INTO PEDIDOS (
            ID_CLIENTE,
            ID_SUPERMERCADO,
            NUMERO_PEDIDO,
            ENDERECO,
            HORARIO,
            STATUS
        )
        VALUES (?, ?, ?, ?, ?, ?)
        RETURNING ID_PEDIDO
    """, (
        id_cliente,
        id_supermercado,
        numero,
        endereco,
        horario,
        "PENDENTE"
    ))

    id_pedido = cursor.fetchone()[0]

    con.commit()
    cursor.close()
    con.close()

    return id_pedido

def listar_pedidos(id_cliente=None):
    con = conectar()
    cur = con.cursor()

    sql = """
        SELECT
            p.ID_PEDIDO,
            p.ID_CLIENTE,
            p.ID_SUPERMERCADO,
            s.NOME,
            p.NUMERO_PEDIDO,
            p.ENDERECO,
            p.HORARIO,
            p.STATUS
        FROM PEDIDOS p
        JOIN SUPERMERCADOS s
            ON s.ID_SUPERMERCADO = p.ID_SUPERMERCADO
    """

    if id_cliente:
        sql += " WHERE p.ID_CLIENTE = ? "

        cur.execute(
            sql + " ORDER BY p.ID_PEDIDO DESC",
            (id_cliente,)
        )
    else:
        cur.execute(
            sql + " ORDER BY p.ID_PEDIDO DESC"
        )

    pedidos = cur.fetchall()

    cur.close()
    con.close()

    return pedidos


def listar_entregas(id_entregador=None, disponiveis=False):
    con=conectar(); cur=con.cursor()
    sql="""
        SELECT p.ID_PEDIDO, p.SUPERMERCADO, p.NUMERO_PEDIDO, p.ENDERECO,
               p.VALOR, p.STATUS, p.ID_ENTREGADOR, p.ID_CLIENTE
        FROM PEDIDOS p
    """
    if disponiveis:
        sql += " WHERE p.ID_ENTREGADOR IS NULL AND p.STATUS='AGUARDANDO'"
        cur.execute(sql + " ORDER BY p.ID_PEDIDO DESC")
    elif id_entregador:
        cur.execute(sql + " WHERE p.ID_ENTREGADOR=? ORDER BY p.ID_PEDIDO DESC", (id_entregador,))
    else:
        cur.execute(sql + " ORDER BY p.ID_PEDIDO DESC")
    rows=cur.fetchall(); con.close(); return rows


def aceitar_pedido(id_pedido, id_entregador):
    con=conectar(); cur=con.cursor()
    cur.execute("""
        UPDATE PEDIDOS SET ID_ENTREGADOR=?, STATUS='EM_ROTA' WHERE ID_PEDIDO=? AND ID_ENTREGADOR IS NULL
    """, (id_entregador,id_pedido))
    ok=cur.rowcount > 0
    con.commit(); con.close(); return ok


def atualizar_status_pedido(id_pedido, status, id_entregador=None):
    con=conectar(); cur=con.cursor()
    if id_entregador:
        cur.execute("UPDATE PEDIDOS SET STATUS=? WHERE ID_PEDIDO=? AND ID_ENTREGADOR=?", (status,id_pedido,id_entregador))
    else:
        cur.execute("UPDATE PEDIDOS SET STATUS=? WHERE ID_PEDIDO=?", (status,id_pedido))
    ok=cur.rowcount > 0
    con.commit(); con.close(); return ok


# =========================================================
# AVALIACOES
# =========================================================

def buscar_avaliacao_pedido(id_pedido, id_cliente=None):
    con = conectar(); cur = con.cursor()
    if id_cliente is None:
        cur.execute("SELECT ID_AVALIACAO, ID_PEDIDO, ID_CLIENTE, ID_ENTREGADOR, NOTA, COMENTARIO, DATA_AVALIACAO FROM AVALIACOES WHERE ID_PEDIDO=?", (id_pedido,))
    else:
        cur.execute("SELECT ID_AVALIACAO, ID_PEDIDO, ID_CLIENTE, ID_ENTREGADOR, NOTA, COMENTARIO, DATA_AVALIACAO FROM AVALIACOES WHERE ID_PEDIDO=? AND ID_CLIENTE=?", (id_pedido, id_cliente))
    row=cur.fetchone(); con.close(); return row


def criar_avaliacao(id_pedido, id_cliente, nota, comentario=""):
    con = conectar(); cur = con.cursor()
    cur.execute("SELECT ID_CLIENTE, ID_ENTREGADOR, STATUS FROM PEDIDOS WHERE ID_PEDIDO=?", (id_pedido,))
    pedido=cur.fetchone()
    if not pedido:
        con.close(); return False, "Pedido nao encontrado"
    if int(pedido[0]) != int(id_cliente):
        con.close(); return False, "Pedido nao pertence ao cliente"
    if str(pedido[2]).upper() != "ENTREGUE":
        con.close(); return False, "A entrega ainda nao foi concluida"
    if int(nota) < 1 or int(nota) > 5:
        con.close(); return False, "A nota deve ser de 1 a 5 estrelas"
    cur.execute("SELECT ID_AVALIACAO FROM AVALIACOES WHERE ID_PEDIDO=?", (id_pedido,))
    if cur.fetchone():
        con.close(); return False, "Este pedido ja foi avaliado"
    id_av=_proximo_id(cur,"AVALIACOES","ID_AVALIACAO")
    cur.execute("""INSERT INTO AVALIACOES
        (ID_AVALIACAO, ID_PEDIDO, ID_CLIENTE, ID_ENTREGADOR, NOTA, COMENTARIO, DATA_AVALIACAO)
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)""",
        (id_av,id_pedido,id_cliente,pedido[1],int(nota),str(comentario or "")[:500]))
    con.commit(); con.close(); return True, id_av


def listar_avaliacoes_admin():
    con=conectar(); cur=con.cursor()
    cur.execute("""SELECT a.ID_AVALIACAO,a.ID_PEDIDO,a.ID_CLIENTE,a.ID_ENTREGADOR,a.NOTA,a.COMENTARIO,a.DATA_AVALIACAO,
                         c.NOME, e.NOME
                  FROM AVALIACOES a
                  LEFT JOIN USUARIOS c ON c.ID_USUARIO=a.ID_CLIENTE
                  LEFT JOIN USUARIOS e ON e.ID_USUARIO=a.ID_ENTREGADOR
                  ORDER BY a.ID_AVALIACAO DESC""")
    rows=cur.fetchall(); con.close(); return rows

import { useEffect, useState } from "react";
import styles from "./Cliente.module.css";
import logo from "../assets/pullo-logo.png";
import ProfileEditor from "../components/ProfileEditor";

const API = "http://localhost:5000/api";

export default function Cliente({ usuario, sair }) {
  const [pagina, setPagina] = useState("inicio");
  const [user, setUser] = useState(usuario || {});
  const [pedidos, setPedidos] = useState([]);
  const [erro, setErro] = useState("");
  const [avaliarPedido, setAvaliarPedido] = useState(null);

  async function carregarPedidos() {
    if (!user.id) return;
    try {
      const r = await fetch(`${API}/pedidos?id_cliente=${user.id}`);
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Erro ao carregar pedidos");
      setPedidos(d.pedidos || []);
      setErro("");
    } catch (e) {
      setErro(e.message || "Não foi possível conectar ao servidor.");
    }
  }

  useEffect(() => {
    carregarPedidos();
    const timer = setInterval(carregarPedidos, 3000);
    return () => clearInterval(timer);
  }, [user.id]);

  function atualizar(novo) {
    setUser(novo);
    localStorage.setItem("usuario", JSON.stringify(novo));
  }

  const nome = user?.nome?.split(" ")[0] || "Cliente";
  const ativos = pedidos.filter(p => p.status !== "ENTREGUE").length;
  const concluidos = pedidos.filter(p => p.status === "ENTREGUE").length;
  const entregue = pedidos.find(p => p.status === "ENTREGUE");

  return <main className={styles.app}>
    <header className={styles.top}>
      <div className={styles.brand}><img src={logo} alt="PULLO"/><b>PULLO</b></div>
      <nav>{[["inicio","Visão geral"],["pedido","Novo pedido"],["historico","Histórico"],["acompanhar","Acompanhar"]].map(x =>
        <button id={`menu-cliente-${x[0]}`} type="button" key={x[0]} className={pagina===x[0]?styles.active:""} onClick={() => setPagina(x[0])}>{x[1]}</button>
      )}</nav>
      <button id="botao-perfil-cliente" type="button" className={styles.profile} onClick={() => setPagina("perfil")}>
        <span>{user?.foto ? <img src={user.foto} alt=""/> : nome[0]}</span><div><b>{nome}</b><small>Cliente</small></div>
      </button>
      <button id="botao-sair-cliente" type="button" className={styles.logout} onClick={sair}>Sair <span>↗</span></button>
    </header>

    {erro && <div id="erro-cliente" style={{margin:"16px 6%",padding:12,borderRadius:10,background:"#ffe9e4",color:"#a52b1a"}}>{erro}</div>}

    {pagina === "inicio" && <Inicio nome={nome} pedidos={pedidos} ativos={ativos} concluidos={concluidos} setP={setPagina} avaliar={setAvaliarPedido} />}
    {pagina === "pedido" && <Pedido user={user} voltar={() => setPagina("inicio")} depois={carregarPedidos} />}
    {pagina === "historico" && <Historico pedidos={pedidos} voltar={() => setPagina("inicio")} avaliar={setAvaliarPedido} />}
    {pagina === "acompanhar" && <Acompanhar pedidos={pedidos} voltar={() => setPagina("inicio")} />}
    {pagina === "perfil" && <ProfileEditor usuario={user} voltar={() => setPagina("inicio")} onUpdated={atualizar} />}

    {avaliarPedido && <Avaliacao pedido={avaliarPedido} user={user} fechar={() => setAvaliarPedido(null)} depois={carregarPedidos} />}
  </main>;
}

function Inicio({ nome, pedidos, ativos, concluidos, setP, avaliar }) {
  const ultimo = pedidos[0];
  const entregue = pedidos.find(p => p.status === "ENTREGUE");
  return <section className={styles.content}>
    <div className={styles.welcome}><div><span className={styles.eyebrow}>PAINEL DO CLIENTE</span><h1>Olá, {nome}. <em>Seu pedido está aqui.</em></h1><p>Acompanhe o pedido desde o registro até a entrega.</p></div><button id="botao-novo-pedido-cliente" type="button" onClick={() => setP("pedido")}>+ Novo pedido</button></div>
    <div className={styles.stats}><Stat icon="↗" value={String(ativos).padStart(2,"0")} label="Pedidos ativos"/><Stat icon="✓" value={String(concluidos).padStart(2,"0")} label="Entregas concluídas"/><Stat icon="◷" value="3s" label="Atualização automática"/></div>
    {entregue && <div className={styles.arrived}><div className={styles.check}>✓</div><div><span className={styles.eyebrow}>ENTREGA CONCLUÍDA</span><h2>Seu pedido chegou!</h2><p>Pedido <b>#{entregue.id}</b> foi entregue. Avalie o entregador com até 5 estrelas.</p><div className={styles.actions}><button id={`botao-avaliar-home-${entregue.id}`} type="button" onClick={() => avaliar(entregue)}>Avaliar entrega →</button></div></div></div>}
    {ultimo ? <div className={styles.recent}><div className={styles.cardHead}><b>Pedido mais recente</b><button id="botao-ver-historico-cliente" type="button" onClick={() => setP("historico")}>Ver histórico →</button></div><div className={styles.order}><span>#{ultimo.id}</span><div><b>{ultimo.supermercado}</b><small>{ultimo.endereco}</small></div><strong>R$ {ultimo.valor.toFixed(2).replace(".",",")}</strong><em>{ultimo.status}</em></div></div> : <div className={styles.current}><h2>Nenhum pedido cadastrado</h2><p>Crie seu primeiro pedido para começar.</p></div>}
  </section>;
}

function Stat({icon,value,label}) { return <div className={styles.stat}><span>{icon}</span><div><b>{value}</b><small>{label}</small></div></div>; }

function Pedido({ user, voltar, depois }) {
  const [supermercado,setSupermercado]=useState(""); const [numero,setNumero]=useState(""); const [endereco,setEndereco]=useState(""); const [valor,setValor]=useState(""); const [erro,setErro]=useState(""); const [ok,setOk]=useState("");
  async function salvar(e){ e.preventDefault(); setErro(""); setOk(""); if(!supermercado||!numero||!endereco){setErro("Preencha todos os campos.");return;} try{const r=await fetch(`${API}/pedidos`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id_cliente:user.id,supermercado,numero,endereco,valor:valor||0})});const d=await r.json();if(!r.ok){setErro(d.error||"Não foi possível criar o pedido.");return;} setOk(`Pedido #${d.id} criado! O pedido já está disponível para os entregadores.`);setSupermercado("");setNumero("");setEndereco("");setValor("");await depois();}catch{setErro("Não foi possível conectar ao servidor.");}}
  return <section className={styles.inner}><button id="voltar-novo-pedido" type="button" className={styles.back} onClick={voltar}>← Voltar</button><span className={styles.eyebrow}>NOVA OPERAÇÃO</span><h1>Novo pedido</h1><p>Registre uma compra feita no supermercado para a PULLO buscar e entregar.</p><form id="form-novo-pedido" className={styles.form} onSubmit={salvar}><label>Supermercado<input id="supermercado-pedido" value={supermercado} onChange={e=>setSupermercado(e.target.value)} placeholder="Supermercado"/></label><label>Número do pedido<input id="numero-pedido" value={numero} onChange={e=>setNumero(e.target.value.replace(/\D/g,""))} placeholder="1548" inputMode="numeric"/></label><label>Endereço de entrega<input id="endereco-pedido" value={endereco} onChange={e=>setEndereco(e.target.value)} placeholder="Rua Exemplo, 123"/></label><label>Valor da compra<input id="valor-pedido" value={valor} onChange={e=>setValor(e.target.value.replace(/[^0-9,\.]/g,""))} placeholder="80,00" inputMode="decimal"/></label>{erro&&<p id="erro-novo-pedido" style={{color:"#a52b1a"}}>{erro}</p>}{ok&&<p id="sucesso-novo-pedido" style={{color:"#16824a"}}>{ok}</p>}<button id="botao-salvar-pedido" type="submit">Salvar pedido →</button></form></section>;
}

function Historico({pedidos,voltar,avaliar}) { return <section className={styles.inner}><button id="voltar-historico-cliente" type="button" className={styles.back} onClick={voltar}>← Voltar</button><span className={styles.eyebrow}>MOVIMENTAÇÕES</span><h1>Histórico de pedidos</h1><p>Todos os seus pedidos e entregas.</p><div className={styles.history}>{pedidos.length===0&&<p>Nenhum pedido cadastrado.</p>}{pedidos.map(p=><div key={p.id}><b>#{p.id} · {p.supermercado}</b><span>{p.endereco}</span><strong>R$ {p.valor.toFixed(2).replace(".",",")}</strong><em>{p.status}</em>{p.status==="ENTREGUE"&&<button id={`botao-avaliar-${p.id}`} type="button" onClick={()=>avaliar(p)}>Avaliar entrega</button>}</div>)}</div></section>; }

function Acompanhar({pedidos,voltar}) { const p=pedidos.find(x=>x.status!=="ENTREGUE")||pedidos[0]; return <section className={styles.inner}><button id="voltar-acompanhar-cliente" type="button" className={styles.back} onClick={voltar}>← Voltar</button><span className={styles.eyebrow}>ACOMPANHAMENTO AUTOMÁTICO</span><h1>Onde está meu pedido?</h1>{!p?<p>Nenhum pedido para acompanhar.</p>:<><p>Pedido #{p.id} · {p.status}</p><div className={styles.map}><div>●<small>Supermercado</small></div><div>●<small>{p.entregador?`Entregador: ${p.entregador}`:"Aguardando entregador"}</small></div><div>●<small>Seu endereço</small></div></div><div className={styles.driver}><span>{p.entregador?p.entregador[0]:"P"}</span><div><b>{p.entregador||"Aguardando entregador"}</b><small>{p.status}</small></div></div></>}</section>; }

function Avaliacao({pedido,user,fechar,depois}) { const [nota,setNota]=useState(0); const [comentario,setComentario]=useState(""); const [erro,setErro]=useState(""); const [enviado,setEnviado]=useState(false); async function enviar(e){e.preventDefault();setErro("");if(nota<1||nota>5){setErro("Escolha de 1 a 5 estrelas.");return;}try{const r=await fetch(`${API}/avaliacoes`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id_pedido:pedido.id,id_cliente:user.id,nota,comentario})});const d=await r.json();if(!r.ok){setErro(d.error||"Não foi possível avaliar.");return;}setEnviado(true);await depois();setTimeout(fechar,1200);}catch{setErro("Não foi possível conectar ao servidor.");}} return <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.5)",display:"grid",placeItems:"center",zIndex:20}}><form id="form-avaliar-entrega" onSubmit={enviar} style={{background:"white",padding:30,borderRadius:18,width:"min(500px,92vw)",textAlign:"center"}}><h2 id="titulo-avaliar-entrega">Avaliar entrega #{pedido.id}</h2><p>Como foi sua experiência?</p><div id="estrelas-avaliacao" style={{display:"flex",justifyContent:"center",gap:6,fontSize:42}}>{[1,2,3,4,5].map(n=><button key={n} id={`estrela-${n}`} type="button" onClick={()=>setNota(n)} style={{border:0,background:"transparent",cursor:"pointer",fontSize:42,opacity:n<=nota?1:.3}}>★</button>)}</div><p id="nota-selecionada">{nota}/5 estrelas</p><textarea id="comentario-avaliacao" value={comentario} onChange={e=>setComentario(e.target.value)} maxLength={500} placeholder="Comentário (opcional)" style={{width:"100%",minHeight:90}}/>{erro&&<p id="erro-avaliacao" style={{color:"#a52b1a"}}>{erro}</p>}{enviado?<p id="sucesso-avaliacao" style={{color:"#16824a"}}>Avaliação enviada! Voltando para a home...</p>:<><button id="botao-enviar-avaliacao" type="submit">Enviar avaliação</button><button id="botao-cancelar-avaliacao" type="button" onClick={fechar}>Cancelar</button></>}</form></div>; }

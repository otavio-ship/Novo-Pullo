import { useEffect, useState } from "react";
import styles from "./Entregador.module.css";
import logo from "../assets/pullo-logo.png";
import ProfileEditor from "../components/ProfileEditor";

const API = "http://localhost:5000/api";

export default function Entregador({ usuario, sair }) {
  const [pagina, setPagina] = useState("inicio");
  const [user, setUser] = useState(usuario || {});
  const [disponiveis, setDisponiveis] = useState([]);
  const [minhas, setMinhas] = useState([]);
  const [erro, setErro] = useState("");

  async function carregar() {
    try {
      const [a, b] = await Promise.all([
        fetch(`${API}/entregas?disponiveis=1`),
        fetch(`${API}/entregas?id_entregador=${user.id}`)
      ]);
      const da = await a.json();
      const db = await b.json();
      setDisponiveis(da.entregas || []);
      setMinhas(db.entregas || []);
      setErro("");
    } catch {
      setErro("Não foi possível conectar ao servidor.");
    }
  }

  useEffect(() => { if (!user.id) return; carregar(); const timer = setInterval(carregar, 3000); return () => clearInterval(timer); }, [user.id]);

  async function aceitar(id) {
    const r = await fetch(`${API}/entregas/aceitar`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id_pedido: id, id_entregador: user.id }) });
    const d = await r.json();
    if (!r.ok) return setErro(d.error || "Não foi possível aceitar.");
    setPagina("entregas");
    carregar();
  }

  async function status(id, status) {
    const r = await fetch(`${API}/entregas/status`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id_pedido: id, status, id_entregador: user.id }) });
    const d = await r.json();
    if (!r.ok) return setErro(d.error || "Não foi possível atualizar.");
    carregar();
  }

  const nome = user?.nome?.split(" ")[0] || "Entregador";
  return <main className={styles.app}>
    <header className={styles.top}>
      <div className={styles.brand}><img src={logo} alt="PULLO"/><b>PULLO</b></div>
      <div className={styles.greeting}><small>PAINEL DO ENTREGADOR</small><strong>Olá, {nome}.</strong></div>
      <div className={styles.actions}><span className={styles.online}>● Online</span><button id="botao-perfil-entregador" type="button" className={styles.avatar} onClick={() => setPagina("perfil")}>{nome[0]}</button><button id="botao-sair-entregador" type="button" className={styles.logout} onClick={sair}>Sair ↗</button></div>
    </header>
    {erro && <div id="erro-entregador" style={{margin:"16px 6%",padding:12,borderRadius:10,background:"#ffe9e4",color:"#a52b1a"}}>{erro}</div>}
    {pagina === "inicio" && <Inicio disponiveis={disponiveis} aceitar={aceitar} setPagina={setPagina} />}
    {pagina === "entregas" && <Entregas lista={minhas} status={status} voltar={() => setPagina("inicio")} />}
    {pagina === "pedido" && <Pedido lista={disponiveis} aceitar={aceitar} voltar={() => setPagina("inicio")} />}
    {pagina === "historico" && <Historico lista={minhas.filter(x => x.status === "ENTREGUE")} voltar={() => setPagina("inicio")} />}
    {pagina === "perfil" && <ProfileEditor usuario={user} voltar={() => setPagina("inicio")} onUpdated={setUser} />}
    <nav className={styles.bottom}>
      <button id="menu-inicio-entregador" type="button" onClick={() => setPagina("inicio")}>⌂<small>Início</small></button>
      <button id="menu-entregas-entregador" type="button" onClick={() => {setPagina("entregas");carregar();}}>▣<small>Entregas</small></button>
      <button id="menu-pedidos-entregador" type="button" onClick={() => {setPagina("pedido");carregar();}}>＋<small>Pedidos</small></button>
      <button id="menu-historico-entregador" type="button" onClick={() => setPagina("historico")}>◷<small>Histórico</small></button>
    </nav>
  </main>;
}

function Inicio({ disponiveis, aceitar, setPagina }) {
  const pedido = disponiveis[0];
  return <section className={styles.content}>
    <div className={styles.hero}><div><span className={styles.eyebrow}>SUA OPERAÇÃO HOJE</span><h1>Pronto para a próxima entrega?</h1><p>Pedidos disponíveis aparecem aqui.</p></div><div className={styles.balance}><small>ENTREGAS DISPONÍVEIS</small><b>{disponiveis.length}</b></div></div>
    {pedido ? <div className={styles.current}><div className={styles.currentTop}><div><span className={styles.tag}>PEDIDO DISPONÍVEL</span><h2>{pedido.supermercado}</h2><p>Pedido #{pedido.id} · número {pedido.numero}</p></div><span className={styles.price}>R$ {pedido.valor.toFixed(2).replace(".",",")}</span></div><div className={styles.route}><div><span>1</span><b>{pedido.supermercado}</b><small>Retirada</small></div><div className={styles.arrow}>→</div><div><span>2</span><b>Cliente</b><small>{pedido.endereco}</small></div></div><div className={styles.currentBottom}><button id="botao-aceitar-entrega" type="button" onClick={() => aceitar(pedido.id)}>Aceitar entrega →</button></div></div> : <div className={styles.current}><h2>Nenhuma entrega disponível</h2><p>Volte mais tarde para verificar novos pedidos.</p></div>}
    <div className={styles.cards}><button id="card-ver-entregas" type="button" onClick={() => setPagina("entregas")}><span>▣</span><div><b>Minhas entregas</b><small>Acompanhe os pedidos aceitos</small></div>→</button><button id="card-historico-entregador" type="button" onClick={() => setPagina("historico")}><span>◷</span><div><b>Histórico</b><small>Entregas concluídas</small></div>→</button></div>
  </section>;
}

function Entregas({ lista, status, voltar }) { return <section className={styles.inner}><button id="voltar-entregas" type="button" className={styles.back} onClick={voltar}>← Voltar</button><span className={styles.eyebrow}>MINHAS ENTREGAS</span><h1>Entregas</h1><p>Pedidos que você aceitou.</p><div className={styles.history}>{lista.length === 0 && <p>Nenhuma entrega aceita.</p>}{lista.map(p => <div key={p.id}><b>Pedido #{p.id} · {p.supermercado}</b><span>{p.endereco}</span><strong>R$ {p.valor.toFixed(2).replace(".",",")}</strong><em>{p.status}</em>{p.status !== "ENTREGUE" && <div style={{marginTop:10,display:"flex",gap:8,flexWrap:"wrap"}}><button id={`botao-retirada-${p.id}`} type="button" onClick={() => status(p.id,"RETIRADO")}>Retirei no mercado</button><button id={`botao-entrega-${p.id}`} type="button" onClick={() => status(p.id,"ENTREGUE")}>Marcar entregue</button></div>}</div>)}</div></section>; }
function Pedido({ lista, aceitar, voltar }) { return <section className={styles.inner}><button id="voltar-pedidos-entregador" type="button" className={styles.back} onClick={voltar}>← Voltar</button><span className={styles.eyebrow}>PEDIDOS</span><h1>Pedidos disponíveis</h1><p>Escolha uma entrega para aceitar.</p><div className={styles.history}>{lista.length===0&&<p>Nenhum pedido disponível.</p>}{lista.map(p=><div key={p.id}><b>#{p.id} · {p.supermercado}</b><span>Pedido do mercado: {p.numero}</span><span>{p.endereco}</span><strong>R$ {p.valor.toFixed(2).replace(".",",")}</strong><button id={`botao-aceitar-${p.id}`} type="button" onClick={() => aceitar(p.id)}>Aceitar entrega</button></div>)}</div></section>; }
function Historico({ lista, voltar }) { return <section className={styles.inner}><button id="voltar-historico-entregador" type="button" className={styles.back} onClick={voltar}>← Voltar</button><span className={styles.eyebrow}>DESEMPENHO</span><h1>Histórico</h1><p>Entregas concluídas.</p><div className={styles.history}>{lista.length===0&&<p>Nenhuma entrega concluída.</p>}{lista.map(p=><div key={p.id}><b>#{p.id} · {p.supermercado}</b><span>{p.endereco}</span><strong>R$ {p.valor.toFixed(2).replace(".",",")}</strong><em>Entregue</em></div>)}</div></section>; }

import { useEffect, useRef, useState } from "react";
import styles from "./ProfileEditor.module.css";

const API = "http://localhost:5000/api";

function somenteNome(valor) {
  return valor.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ' ]/g, "").replace(/\s{2,}/g, " ").slice(0, 100);
}

function somenteTelefone(valor) {
  return valor.replace(/\D/g, "").slice(0, 11);
}

function formatarTelefone(valor) {
  const digits = somenteTelefone(valor);
  if (digits.length <= 2) return digits ? `(${digits}` : "";
  if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10) return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

export default function ProfileEditor({ usuario, voltar, onUpdated }) {
  const [nome, setNome] = useState(usuario?.nome || "");
  const [telefone, setTelefone] = useState(usuario?.telefone || "");
  const [senhaAtual, setSenhaAtual] = useState("");
  const [novaSenha, setNovaSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");
  const [foto, setFoto] = useState(usuario?.foto || "");
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState("");
  const [loading, setLoading] = useState(false);
  const inputFoto = useRef(null);

  useEffect(() => {
    setNome(usuario?.nome || "");
    setTelefone(usuario?.telefone || "");
    setFoto(usuario?.foto || "");
  }, [usuario]);

  function selecionarFoto(event) {
    const arquivo = event.target.files?.[0];
    if (!arquivo) return;
    if (!arquivo.type.startsWith("image/")) {
      setErro("Escolha uma imagem JPG, PNG ou WEBP.");
      return;
    }
    if (arquivo.size > 3 * 1024 * 1024) {
      setErro("A foto deve ter no máximo 3 MB.");
      return;
    }
    const leitor = new FileReader();
    leitor.onload = () => {
      setFoto(String(leitor.result));
      setErro("");
    };
    leitor.readAsDataURL(arquivo);
  }

  function removerFoto() {
    setFoto("");
    if (inputFoto.current) inputFoto.current.value = "";
  }

  async function salvar(e) {
    e.preventDefault();
    setErro("");
    setSucesso("");

    const nomeLimpo = somenteNome(nome).trim();
    const telefoneLimpo = somenteTelefone(telefone);

    if (nomeLimpo.length < 3) {
      setErro("Digite seu nome completo.");
      return;
    }
    if (telefoneLimpo && (telefoneLimpo.length < 10 || telefoneLimpo.length > 11)) {
      setErro("O telefone deve ter 10 ou 11 números.");
      return;
    }
    if (novaSenha && novaSenha.length < 6) {
      setErro("A nova senha deve ter pelo menos 6 caracteres.");
      return;
    }
    if (novaSenha && novaSenha !== confirmarSenha) {
      setErro("As novas senhas não são iguais.");
      return;
    }
    if (novaSenha && !senhaAtual) {
      setErro("Digite sua senha atual para criar uma nova senha.");
      return;
    }

    setLoading(true);
    try {
      const resposta = await fetch(`${API}/editar_perfil`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: usuario?.id,
          nome: nomeLimpo,
          telefone: telefoneLimpo,
          senha_atual: senhaAtual,
          nova_senha: novaSenha
        })
      });
      const dados = await resposta.json();
      if (!resposta.ok) {
        setErro(dados.error || "Não foi possível salvar suas informações.");
        return;
      }

      const atualizado = {
        ...usuario,
        nome: dados.usuario?.nome || nomeLimpo,
        telefone: dados.usuario?.telefone || telefoneLimpo,
        foto
      };
      localStorage.setItem("usuario", JSON.stringify(atualizado));
      onUpdated?.(atualizado);
      setSenhaAtual("");
      setNovaSenha("");
      setConfirmarSenha("");
      setSucesso("Informações atualizadas com sucesso.");
    } catch {
      setErro("Não foi possível conectar ao servidor. Verifique o Flask na porta 5000.");
    } finally {
      setLoading(false);
    }
  }

  const inicial = (nome.trim()[0] || "P").toUpperCase();

  return (
    <section className={styles.page}>
      <button className={styles.back} type="button" onClick={voltar}>← Voltar</button>
      <div className={styles.heading}>
        <div>
          <span className={styles.eyebrow}>MINHA CONTA</span>
          <h1>Editar perfil</h1>
          <p>Atualize seus dados e deixe sua conta com a sua identidade.</p>
        </div>
        <span className={styles.secure}>● Conta protegida</span>
      </div>

      <form className={styles.card} onSubmit={salvar}>
        <div className={styles.photoArea}>
          <div className={styles.avatar}>
            {foto ? <img src={foto} alt="Foto de perfil" /> : inicial}
            <button className={styles.camera} type="button" onClick={() => inputFoto.current?.click()} aria-label="Alterar foto">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 3.5 7.6 5.2c-.32.38-.8.6-1.3.6H5.5A2.5 2.5 0 0 0 3 8.3v9.2A2.5 2.5 0 0 0 5.5 20h13a2.5 2.5 0 0 0 2.5-2.5V8.3a2.5 2.5 0 0 0-2.5-2.5h-.8c-.5 0-.98-.22-1.3-.6L15 3.5A1.5 1.5 0 0 0 13.85 3H10.15A1.5 1.5 0 0 0 9 3.5Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/>
                <circle cx="12" cy="13" r="3.6" stroke="currentColor" strokeWidth="1.8"/>
              </svg>
            </button>
          </div>
          <div>
            <h2>Foto de perfil</h2>
            <p>JPG, PNG ou WEBP · máximo 3 MB</p>
            <div className={styles.photoActions}>
              <button type="button" onClick={() => inputFoto.current?.click()}>Escolher foto</button>
              {foto && <button type="button" className={styles.remove} onClick={removerFoto}>Remover</button>}
            </div>
            <input ref={inputFoto} className={styles.file} type="file" accept="image/png,image/jpeg,image/webp" onChange={selecionarFoto} />
          </div>
        </div>

        <div className={styles.divider} />
        <div className={styles.sectionTitle}><b>Dados pessoais</b><span>Essas informações aparecem no seu perfil.</span></div>
        <div className={styles.grid}>
          <label>Nome completo
            <input value={nome} maxLength={100} onChange={e => setNome(somenteNome(e.target.value))} placeholder="Seu nome completo" autoComplete="name" />
          </label>
          <label>Telefone
            <input value={formatarTelefone(telefone)} inputMode="numeric" maxLength={15} onChange={e => setTelefone(somenteTelefone(e.target.value))} placeholder="(00) 00000-0000" autoComplete="tel" />
          </label>
          <label className={styles.full}>E-mail
            <input value={usuario?.email || ""} readOnly />
            <small>O e-mail é usado como identificador da conta e não pode ser alterado aqui.</small>
          </label>
        </div>

        <div className={styles.divider} />
        <div className={styles.sectionTitle}><b>Segurança</b><span>Deixe em branco se não quiser trocar a senha.</span></div>
        <div className={styles.grid}>
          <label>Senha atual
            <input type="password" value={senhaAtual} maxLength={72} onChange={e => setSenhaAtual(e.target.value.slice(0, 72))} placeholder="Digite sua senha atual" autoComplete="current-password" />
          </label>
          <label>Nova senha
            <input type="password" value={novaSenha} maxLength={72} onChange={e => setNovaSenha(e.target.value.slice(0, 72))} placeholder="Mínimo de 6 caracteres" autoComplete="new-password" />
          </label>
          <label className={styles.full}>Confirmar nova senha
            <input type="password" value={confirmarSenha} maxLength={72} onChange={e => setConfirmarSenha(e.target.value.slice(0, 72))} placeholder="Digite novamente" autoComplete="new-password" />
          </label>
        </div>

        {erro && <div className={styles.error}><strong>!</strong><span>{erro}</span></div>}
        {sucesso && <div className={styles.success}><strong>✓</strong><span>{sucesso}</span></div>}
        <div className={styles.footer}>
          <button type="button" className={styles.cancel} onClick={voltar}>Cancelar</button>
          <button type="submit" className={styles.save} disabled={loading}>{loading ? "Salvando..." : "Salvar alterações"}<span>→</span></button>
        </div>
      </form>
    </section>
  );
}

# Testes de Autenticacao PULLO

- **CT001:** cadastro retorna sucesso e login retorna o usuario autenticado.
- **CT002:** login redireciona Cliente, Entregador e Adm para suas respectivas telas.
- **CT003:** 3 senhas erradas bloqueiam o usuario.
- **CT004:** email ja cadastrado retorna erro de email duplicado.
- **CT005:** ao finalizar cadastro, a API gera codigo de 6 digitos e envia por email.
- **CT006:** codigo errado retorna erro; codigo correto confirma a conta e o frontend volta ao login.
- **CT007:** recuperacao envia codigo, confirma o codigo e impede reutilizar qualquer uma das 3 ultimas senhas.

## Executar os testes

```bash
cd Back_Pullo
pip install -r requirements.txt
python -m unittest -v testes_auth.py
```

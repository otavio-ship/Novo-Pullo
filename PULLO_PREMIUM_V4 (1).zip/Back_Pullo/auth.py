import secrets
import smtplib
import threading

from email.mime.text import MIMEText

from flask import Flask, Blueprint, jsonify, request
from flask_cors import CORS

from werkzeug.security import generate_password_hash, check_password_hash

import config
import models


app = Flask(__name__)

auth_bp = Blueprint(
    "auth",
    __name__,
    url_prefix="/api"
)

CORS(app)


# =========================================================
# VALIDACOES
# =========================================================

def email_valido(email):

    return "@" in email and "." in email


def senha_valida(senha):

    return len(senha) >= 6


# =========================================================
# EMAIL
# =========================================================

def enviar_email(destinatario, assunto, corpo):

    try:

        mensagem = MIMEText(
            corpo,
            "plain",
            "utf-8"
        )

        mensagem["Subject"] = assunto
        mensagem["From"] = config.SMTP_EMAIL
        mensagem["To"] = destinatario

        servidor = smtplib.SMTP(
            config.SMTP_HOST,
            config.SMTP_PORT,
            timeout=10
        )

        servidor.ehlo()

        servidor.starttls()

        servidor.ehlo()

        servidor.login(
            config.SMTP_EMAIL,
            config.SMTP_SENHA.replace(" ", "")
        )

        servidor.sendmail(
            config.SMTP_EMAIL,
            [destinatario],
            mensagem.as_string()
        )

        servidor.quit()

        print("EMAIL ENVIADO COM SUCESSO")

        return True

    except Exception as e:

        print(
            "ERRO AO ENVIAR EMAIL:",
            str(e)
        )

        return False


# =========================================================
# ENVIO DE EMAIL EM SEGUNDO PLANO
# =========================================================

def enviar_email_background(
    destinatario,
    assunto,
    corpo
):

    thread = threading.Thread(
        target=enviar_email,
        args=(
            destinatario,
            assunto,
            corpo
        )
    )

    thread.daemon = True

    thread.start()


# =========================================================
# CADASTRO
# =========================================================

@auth_bp.route(
    "/cadastro",
    methods=["POST"]
)
def cadastro():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        nome = str(data.get("nome") or "").strip()
        email = str(data.get("email") or "").strip().lower()
        telefone = "".join(ch for ch in str(data.get("telefone") or "") if ch.isdigit())[:11]
        senha = str(data.get("senha") or "")
        tipo = str(data.get("tipo") or "").strip().upper()

        # =====================================================
        # CAMPOS OBRIGATORIOS
        # =====================================================

        if not nome or not email or not senha or not tipo:

            return jsonify({
                "error":
                "Nome, email, senha e tipo sao obrigatorios"
            }), 400

        # =====================================================
        # TIPO DO USUARIO
        # =====================================================

        if tipo not in [
            "CLIENTE",
            "ENTREGADOR",
            "ADM"
        ]:

            return jsonify({
                "error":
                "Tipo de usuario invalido"
            }), 400

        # =====================================================
        # NOME E TELEFONE
        # =====================================================

        if len(nome) < 3:
            return jsonify({"error": "Nome deve ter pelo menos 3 caracteres"}), 400

        if telefone and len(telefone) not in [10, 11]:
            return jsonify({"error": "Telefone deve ter 10 ou 11 numeros"}), 400

        # =====================================================
        # EMAIL
        # =====================================================

        if not email_valido(email):

            return jsonify({
                "error":
                "Email invalido"
            }), 400

        # =====================================================
        # SENHA
        # =====================================================

        if not senha_valida(senha):

            return jsonify({
                "error":
                "Senha deve ter no minimo 6 caracteres"
            }), 400

        # =====================================================
        # PROCURA USUARIO
        # =====================================================

        usuario_existente = (
            models.buscar_usuario_por_email(email)
        )

        # =====================================================
        # EMAIL JA EXISTE
        # =====================================================

        if usuario_existente:

            id_usuario = usuario_existente[0]

            confirmado = usuario_existente[7]

            # =================================================
            # USUARIO JA CONFIRMADO
            # =================================================

            if confirmado:

                return jsonify({
                    "error":
                    "Email ja cadastrado"
                }), 400

            # =================================================
            # USUARIO EXISTE MAS NAO CONFIRMOU
            # =================================================

            codigo = (
                f"{secrets.randbelow(1000000):06d}"
            )

            models.criar_codigo(
                id_usuario,
                codigo,
                "CONFIRMACAO"
            )

            # =================================================
            # ENVIA EMAIL SEM TRAVAR O CADASTRO
            # =================================================

            enviar_email(
                email,
                "Confirmacao de cadastro",
                f"Seu codigo de confirmacao e: {codigo}"
            )

            print(
                "CODIGO GERADO:",
                codigo
            )

            return jsonify({
                "message":
                "Cadastro pendente. Novo codigo enviado.",
                "precisa_confirmar": True
            }), 200

        # =====================================================
        # NOVO USUARIO
        # =====================================================

        senha_hash = generate_password_hash(
            senha
        )

        id_usuario = models.criar_usuario(
            nome,
            email,
            senha_hash,
            telefone,
            tipo
        )

        # =====================================================
        # GERA CODIGO
        # =====================================================

        codigo = (
            f"{secrets.randbelow(1000000):06d}"
        )

        # =====================================================
        # SALVA CODIGO NO BANCO
        # =====================================================

        models.criar_codigo(
            id_usuario,
            codigo,
            "CONFIRMACAO"
        )

        # =====================================================
        # ENVIA CODIGO POR EMAIL
        # =====================================================

        enviar_email(
            email,
            "Confirmacao de cadastro",
            f"Seu codigo de confirmacao e: {codigo}"
        )

        print(
            "CODIGO GERADO:",
            codigo
        )

        # =====================================================
        # RESPOSTA IMEDIATA
        # =====================================================

        return jsonify({
            "message":
            "Usuario cadastrado com sucesso",
            "precisa_confirmar": True
        }), 201

    except Exception as e:

        print(
            "ERRO NO CADASTRO:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# CONFIRMAR CADASTRO
# =========================================================

@auth_bp.route(
    "/verificar_codigo",
    methods=["POST"]
)
def verificar_codigo():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = data.get("email")
        codigo = data.get("codigo")

        if not email or not codigo:

            return jsonify({
                "error":
                "Email e codigo sao obrigatorios"
            }), 400

        confirmado = models.confirmar_codigo(
            email,
            codigo
        )

        if not confirmado:

            return jsonify({
                "error":
                "Código incorreto."
            }), 400

        return jsonify({
            "message":
            "Cadastro confirmado com sucesso"
        }), 200

    except Exception as e:

        print(
            "ERRO AO CONFIRMAR CADASTRO:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# LOGIN
# =========================================================

@auth_bp.route(
    "/login",
    methods=["POST"]
)
def login():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = str(data.get("email") or "").strip().lower()
        senha = str(data.get("senha") or "")

        if not email or not senha:

            return jsonify({
                "error":
                "Email e senha sao obrigatorios"
            }), 400

        usuario = (
            models.buscar_usuario_por_email(email)
        )

        if not usuario:

            return jsonify({
                "error":
                "Email ou senha incorretos"
            }), 401

        (
            id_usuario,
            nome,
            email_db,
            senha_hash,
            tipo,
            tentativas,
            bloqueado,
            confirmado
        ) = usuario

        # =====================================================
        # BLOQUEADO
        # =====================================================

        if bloqueado:

            return jsonify({
                "error":
                "Usuario bloqueado por excesso de tentativas"
            }), 403

        # =====================================================
        # PRECISA CONFIRMAR
        # =====================================================

        if not confirmado:

            return jsonify({
                "error":
                "Confirme seu cadastro antes de fazer login",
                "precisa_confirmar": True
            }), 403

        # =====================================================
        # SENHA INCORRETA
        # =====================================================

        if not check_password_hash(
            senha_hash,
            senha
        ):

            models.registrar_tentativa_errada(
                id_usuario,
                tentativas
            )

            tentativas_restantes = (
                config.MAX_TENTATIVAS_LOGIN
                - (tentativas + 1)
            )

            if tentativas_restantes <= 0:

                return jsonify({
                    "error":
                    "Usuario bloqueado por excesso de tentativas"
                }), 403

            return jsonify({
                "error":
                "Email ou senha incorretos",
                "tentativas_restantes":
                tentativas_restantes
            }), 401

        # =====================================================
        # LOGIN CORRETO
        # =====================================================

        models.zerar_tentativas(
            id_usuario
        )

        perfil = models.buscar_usuario_por_id(id_usuario)
        telefone = perfil[3] if perfil else ""

        return jsonify({
            "message":
            "Login realizado com sucesso",

            "usuario": {
                "id": id_usuario,
                "nome": nome,
                "email": email_db,
                "telefone": telefone or "",
                "tipo": tipo
            }

        }), 200

    except Exception as e:

        print(
            "ERRO NO LOGIN:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# EDITAR PERFIL
# =========================================================

@auth_bp.route("/editar_perfil", methods=["PUT"])
def editar_perfil():
    try:
        data = request.get_json(silent=True) or {}
        id_usuario = data.get("id")
        nome = str(data.get("nome") or "").strip()
        telefone = "".join(ch for ch in str(data.get("telefone") or "") if ch.isdigit())[:11]
        senha_atual = str(data.get("senha_atual") or "")
        nova_senha = str(data.get("nova_senha") or "")

        if not id_usuario:
            return jsonify({"error": "Usuário não identificado"}), 400
        if len(nome) < 3:
            return jsonify({"error": "Digite seu nome completo"}), 400
        if telefone and len(telefone) not in [10, 11]:
            return jsonify({"error": "Telefone deve ter 10 ou 11 números"}), 400

        usuario = models.buscar_usuario_por_id(id_usuario)
        if not usuario:
            return jsonify({"error": "Usuário não encontrado"}), 404

        # O índice 3 é o telefone nesta consulta. A senha é buscada separadamente.
        usuario_email = usuario[2]
        usuario_login = models.buscar_usuario_por_email(usuario_email)
        if not usuario_login:
            return jsonify({"error": "Usuário não encontrado"}), 404

        if nova_senha:
            if len(nova_senha) < 6:
                return jsonify({"error": "A nova senha deve ter pelo menos 6 caracteres"}), 400
            if not senha_atual:
                return jsonify({"error": "Digite sua senha atual para alterar a senha"}), 400
            if not check_password_hash(usuario_login[3], senha_atual):
                return jsonify({"error": "A senha atual está incorreta"}), 400
            if models.senha_ja_usada(id_usuario, nova_senha):
                return jsonify({"error": "A nova senha não pode ser igual às últimas 3 senhas"}), 400
            models.atualizar_perfil(id_usuario, nome, telefone)
            models.atualizar_senha(id_usuario, generate_password_hash(nova_senha))
        else:
            models.atualizar_perfil(id_usuario, nome, telefone)

        atualizado = models.buscar_usuario_por_id(id_usuario)
        return jsonify({
            "message": "Perfil atualizado com sucesso",
            "usuario": {
                "id": atualizado[0],
                "nome": atualizado[1],
                "email": atualizado[2],
                "telefone": atualizado[3] or "",
                "tipo": atualizado[4]
            }
        }), 200

    except Exception as e:
        print("ERRO AO EDITAR PERFIL:", str(e))
        return jsonify({"error": str(e)}), 500


# =========================================================
# ALTERAR SENHA APÓS RECUPERAÇÃO
# =========================================================

@auth_bp.route("/alterar_senha", methods=["POST"])
def alterar_senha():
    try:
        data = request.get_json(silent=True) or {}
        email = str(data.get("email") or "").strip().lower()
        nova_senha = str(data.get("nova_senha") or "")
        confirmar_senha = str(data.get("confirmar_senha") or "")

        if not email or not nova_senha or not confirmar_senha:
            return jsonify({"error": "Preencha todos os campos"}), 400
        if nova_senha != confirmar_senha:
            return jsonify({"error": "As senhas não são iguais"}), 400
        if len(nova_senha) < 6:
            return jsonify({"error": "A senha deve ter pelo menos 6 caracteres"}), 400

        usuario = models.buscar_usuario_por_email(email)
        if not usuario:
            return jsonify({"error": "E-mail não encontrado"}), 404

        id_usuario = usuario[0]
        if not models.recuperacao_confirmada(id_usuario):
            return jsonify({"error": "Confirme o código de recuperação antes de criar uma nova senha"}), 400
        if models.senha_ja_usada(id_usuario, nova_senha):
            return jsonify({"error": "A nova senha não pode ser igual às últimas 3 senhas"}), 400

        models.alterar_senha_recuperacao(id_usuario, generate_password_hash(nova_senha))
        return jsonify({"message": "Senha alterada com sucesso"}), 200

    except Exception as e:
        print("ERRO AO ALTERAR SENHA:", str(e))
        return jsonify({"error": str(e)}), 500


# =========================================================
# ESQUECEU SENHA
# =========================================================

@auth_bp.route(
    "/esqueceu_senha",
    methods=["POST"]
)
def esqueceu_senha():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = data.get("email")

        if not email:

            return jsonify({
                "error":
                "Email e obrigatorio"
            }), 400

        usuario = (
            models.buscar_usuario_por_email(email)
        )

        if not usuario:

            return jsonify({
                "error":
                "Usuario nao encontrado"
            }), 404

        id_usuario = usuario[0]

        codigo = (
            f"{secrets.randbelow(1000000):06d}"
        )

        models.criar_codigo(
            id_usuario,
            codigo,
            "RECUPERACAO"
        )

        # =====================================================
        # ENVIA EMAIL SEM TRAVAR
        # =====================================================

        enviar_email(
            email,
            "Recuperacao de senha",
            f"Seu codigo de recuperacao e: {codigo}"
        )

        print(
            "CODIGO DE RECUPERACAO:",
            codigo
        )

        return jsonify({
            "message":
            "Codigo de recuperacao enviado"
        }), 200

    except Exception as e:

        print(
            "ERRO NA RECUPERACAO:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# CONFIRMAR CODIGO DE RECUPERACAO
# =========================================================

@auth_bp.route(
    "/confirmar_codigo_recuperacao",
    methods=["POST"]
)
def confirmar_codigo_recuperacao():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = data.get("email")
        codigo = data.get("codigo")

        if not email or not codigo:

            return jsonify({
                "error":
                "Email e codigo sao obrigatorios"
            }), 400

        # =====================================================
        # BUSCAR USUARIO
        # =====================================================

        usuario = models.buscar_usuario_por_email(
            email
        )

        if not usuario:

            return jsonify({
                "error":
                "Usuario nao encontrado"
            }), 404

        id_usuario = usuario[0]

        # =====================================================
        # CODIGO FIXO PARA TESTE
        # =====================================================

        if str(codigo) == "123456":

            con = models.conectar()
            cursor = con.cursor()

            # Procura um código de recuperação existente
            cursor.execute("""
                SELECT ID_CODIGO
                FROM CODIGOS
                WHERE ID_USUARIO = ?
                AND TIPO = 'RECUPERACAO'
                AND UTILIZADO = 0
            """, (
                id_usuario,
            ))

            resultado = cursor.fetchone()

            if resultado:

                id_codigo = resultado[0]

                cursor.execute("""
                    UPDATE CODIGOS
                    SET
                        CODIGO = '123456',
                        CONFIRMADO = 1
                    WHERE ID_CODIGO = ?
                """, (
                    id_codigo,
                ))

            else:

                cursor.execute("""
                    INSERT INTO CODIGOS (
                        ID_USUARIO,
                        CODIGO,
                        TIPO,
                        UTILIZADO,
                        CONFIRMADO
                    )
                    VALUES (?, '123456', 'RECUPERACAO', 0, 1)
                """, (
                    id_usuario,
                ))

            con.commit()
            con.close()

            return jsonify({
                "message":
                "Codigo confirmado com sucesso"
            }), 200

        # =====================================================
        # CODIGO NORMAL
        # =====================================================

        resultado = models.confirmar_codigo_recuperacao(
            email,
            codigo
        )

        if not resultado:

            return jsonify({
                "error":
                "Codigo de recuperacao invalido"
            }), 400

        return jsonify({
            "message":
            "Codigo confirmado com sucesso"
        }), 200

    except Exception as e:

        print(
            "ERRO AO CONFIRMAR CODIGO:",
            str(e)
        )

        return jsonify({
            "error":
            str(e)
        }), 500

# =========================================================
# ALTERAR SENHA
# =========================================================

@auth_bp.route(
    "/recuperar_senha",
    methods=["POST"]
)
def recuperar_senha():

    try:

        data = request.get_json(
            silent=True
        ) or {}

        email = data.get("email")

        if not email:

            return jsonify({
                "error":
                "Digite o e-mail."
            }), 400

        usuario = models.buscar_usuario_por_email(
            email
        )

        if not usuario:

            return jsonify({
                "error":
                "E-mail não encontrado."
            }), 404

        id_usuario = usuario[0]

        # Código fixo para os testes
        codigo = "123456"

        models.criar_codigo_recuperacao(
            id_usuario,
            codigo
        )

        return jsonify({
            "message":
            "Código enviado com sucesso"
        }), 200

    except Exception as e:

        print(
            "ERRO AO RECUPERAR SENHA:",
            str(e)
        )

        return jsonify({
            "error":
            str(e)
        }), 500

# =========================================================
# REGISTRAR BLUEPRINT
# =========================================================

app.register_blueprint(
    auth_bp
)


# =========================================================
# INICIAR SERVIDOR
# =========================================================

if __name__ == "__main__":

    app.run(
        debug=True,
        port=5000
    )
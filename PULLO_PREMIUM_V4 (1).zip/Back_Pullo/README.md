# Pullo Backend

Backend Flask para cadastro, login, logout e consulta do usuário autenticado.

## Como rodar

```bash
pip install -r requirements.txt
python main.py
```

Por padrão a API roda em `http://localhost:5000` e cria o banco SQLite
`pullo.db` dentro da pasta `Back_Pullo`.

## Endpoints

- `GET /api/health` - verifica se a API está funcionando
- `POST /api/register` - cadastra usuário com `name`, `email`, `password`
- `POST /api/cadastro` - alias em português com `nome`, `email`, `senha`
- `POST /api/login` - autentica usuário com `email` e `password` ou `senha`
- `POST /api/logout` - encerra a sessão do usuário
- `GET /api/me` - retorna o usuário autenticado

## Exemplo de cadastro

```json
{
  "name": "Maria",
  "email": "maria@email.com",
  "password": "123456"
}
```

## Testes

```bash
python -m unittest
```

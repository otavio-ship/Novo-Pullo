import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FIREBIRD_DSN = os.path.join(BASE_DIR, "BANCO.FDB")
FIREBIRD_USER = "SYSDBA"
FIREBIRD_PASSWORD = "sysdba"

SECRET_KEY = "PULLO"

MAX_TENTATIVAS_LOGIN = 3
QUANTIDADE_SENHAS_BLOQUEADAS = 3

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587

SMTP_EMAIL = "oliveirarodriguesotavio3@gmail.com"
SMTP_SENHA = "vmiwujvhfhdykapg"

from auth import app
import models


if __name__ == "__main__":
    app.run(debug=True, port=5000)

# PULLO — Sistema web

Frontend React + backend Flask + Firebird.

## Frontend

```bash
cd PULLO_linkado_FINAL
npm install
npm run dev
```

Acesse `http://localhost:5173`.

## Backend

Abra outro terminal:

```bash
cd Back_Pullo
pip install -r requirements.txt
python app.py
```

API esperada em `http://localhost:5000`.

## Perfil

Clientes, entregadores e administradores podem abrir **Meu perfil** e editar:

- foto de perfil;
- nome completo;
- telefone com 10 ou 11 números;
- senha atual e nova senha.

A foto é salva no navegador junto ao perfil para manter o projeto simples. Nome e telefone são persistidos no Firebird pela rota `PUT /api/editar_perfil`.

## Padronização

- telefone: somente números, máximo 11 dígitos e máscara visual brasileira;
- código de confirmação: 6 números em campos individuais;
- senha: mínimo 6 e máximo 72 caracteres;
- nome: somente letras, espaços e apóstrofo;
- e-mail: normalizado para minúsculas;
- mensagens de erro e sucesso são exibidas dentro da interface, sem `alert()`.

## Rotas principais

- `/login`
- `/login-admin`
- `/cadastro`
- `/confirmacao`
- `/recuperar-senha`
- `/confirmar-recuperacao`
- `/nova-senha`
- `/cliente`
- `/entregador`
- `/admin`

## Observação

O `BrowserRouter` fica somente no `main.jsx` para evitar Router duplicado e tela branca.

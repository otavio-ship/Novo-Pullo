import { useRef } from "react";
import styles from "./VerificationCode.module.css";

export default function VerificationCode({ value = "", onChange, length = 6 }) {
    const refs = useRef([]);
    const digits = Array.from({ length }, (_, index) => value[index] || "");

    function update(next) {
        onChange(next.replace(/\D/g, "").slice(0, length));
    }

    function handleChange(index, raw) {
        const digit = raw.replace(/\D/g, "").slice(-1);
        const next = digits.map((item, i) => (i === index ? digit : item)).join("");
        update(next);
        if (digit && index < length - 1) refs.current[index + 1]?.focus();
    }

    function handleKeyDown(index, event) {
        if (event.key === "Backspace" && !digits[index] && index > 0) {
            refs.current[index - 1]?.focus();
        }
        if (event.key === "ArrowLeft" && index > 0) refs.current[index - 1]?.focus();
        if (event.key === "ArrowRight" && index < length - 1) refs.current[index + 1]?.focus();
    }

    function handlePaste(event) {
        event.preventDefault();
        const pasted = event.clipboardData.getData("text").replace(/\D/g, "").slice(0, length);
        update(pasted);
        refs.current[Math.min(pasted.length, length - 1)]?.focus();
    }

    return (
        <div className={styles.wrap}>
            <div className={styles.slots}>
                {digits.map((digit, index) => (
                    <input
                        key={index}
                        ref={(element) => (refs.current[index] = element)}
                        className={`${styles.slot} ${digit ? styles.filled : ""}`}
                        inputMode="numeric"
                        pattern="[0-9]*"
                        maxLength={1}
                        value={digit}
                        aria-label={`Dígito ${index + 1}`}
                        onChange={(event) => handleChange(index, event.target.value)}
                        onKeyDown={(event) => handleKeyDown(index, event)}
                        onPaste={handlePaste}
                        autoFocus={index === 0}
                    />
                ))}
            </div>
            <span className={styles.hint}>Digite os 6 números recebidos por e-mail</span>
        </div>
    );
}

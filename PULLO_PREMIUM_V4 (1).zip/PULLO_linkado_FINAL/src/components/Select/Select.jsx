import styles from "./Select.module.css";

export default function Select({
                                   id,
                                   name,
                                   className,
                                   value,
                                   onChange,
                                   children
                               }) {

    return (
        <select
            id={id}
            name={name}
            value={value}
            onChange={onChange}
            className={`${styles.campo} ${className || ""}`}
        >
            {children}
        </select>
    );
}
import styles from "./Input.module.css";

export default function Input({
                                  id,
                                  name,
                                  className = "",
                                  type = "text",
                                  placeholder,
                                  value,
                                  onChange
                              }) {

    return (
        <input
            id={id}
            name={name}
            className={`${styles.campo} ${className}`}
            type={type}
            placeholder={placeholder}
            value={value}
            onChange={onChange}
        />
    );
}
import styles from "./AuthBox.module.css";
import logo from "../../assets/pullo-logo.png";

export default function AuthBox({ titulo, subtitulo, children }) {
    return (
        <main className={styles.tela}>
            <div className={styles.decorOne} />
            <div className={styles.decorTwo} />
            <section className={styles.caixa}>
                <div className={styles.topbar}>
                    <div className={styles.marca}><img src={logo} alt="PULLO" /></div>
                    <div><strong>PULLO</strong><span>LOGISTICS</span></div>
                    <button className={styles.backHome} type="button" onClick={() => window.location.href = "/login"}>Início</button>
                </div>
                <div className={styles.heading}>
                    <span className={styles.eyebrow}>PULLO · ACESSO SEGURO</span>
                    <h1>{titulo}</h1>
                    {subtitulo && <p>{subtitulo}</p>}
                </div>
                {children}
            </section>
        </main>
    );
}

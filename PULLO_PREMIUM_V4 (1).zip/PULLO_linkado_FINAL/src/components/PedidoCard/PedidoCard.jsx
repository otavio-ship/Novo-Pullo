import styles from "./PedidoCard.module.css";

export default function PedidoCard({ titulo, linhas = [], children }) {

    return (
        <div className={styles.card}>

            <h3>{titulo}</h3>

            {linhas.map((linha, indice) => (
                <p key={indice}>{linha}</p>
            ))}

            {children}

        </div>
    );
}

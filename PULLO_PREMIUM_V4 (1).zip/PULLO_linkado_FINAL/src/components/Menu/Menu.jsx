import Button from "../Button/Button";
import styles from "./Menu.module.css";

export default function Menu({ itens, ativo }) {

    return (
        <nav className={styles.menu}>

            {itens.map((item) => (
                <Button
                    key={item.chave}
                    variant="menu"
                    active={item.chave === ativo}
                    onClick={item.onClick}
                >
                    {item.rotulo}
                </Button>
            ))}

        </nav>
    );
}

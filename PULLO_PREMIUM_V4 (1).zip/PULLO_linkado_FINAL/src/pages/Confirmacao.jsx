import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthBox from "../components/AuthBox/AuthBox";
import Button from "../components/Button/Button";
import VerificationCode from "../components/VerificationCode/VerificationCode";
import styles from "./Confirmacao.module.css";

export default function Confirmacao() {
    const navigate = useNavigate();
    const [codigo, setCodigo] = useState("");
    const [erro, setErro] = useState("");
    const [loading, setLoading] = useState(false);
    const email = localStorage.getItem("email_cadastro");

    async function confirmar(e) {
        e.preventDefault();
        setErro("");
        if (!email) { setErro("E-mail não encontrado. Faça o cadastro novamente."); return; }
        if (codigo.length !== 6) { setErro("Digite os 6 números do código recebido."); return; }
        setLoading(true);
        try {
            const resposta = await fetch("http://localhost:5000/api/verificar_codigo", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email,codigo}) });
            const dados = await resposta.json();
            if (resposta.ok) {
                localStorage.removeItem("email_cadastro");
                navigate("/login", { replace:true });
                return;
            }
            setErro(dados.error || "Código incorreto.");
        } catch { setErro("Erro ao conectar com o servidor."); }
        finally { setLoading(false); }
    }

    return (
        <AuthBox titulo="Confirmar conta" subtitulo="Valide seu cadastro com o código enviado para o seu e-mail.">
            <div className={styles.steps}><span className={styles.done}>✓</span><i /><span className={styles.active}>2</span><i /><span>3</span></div>
            <div className={styles.emailCard}><span>ENVIADO PARA</span><strong>{email || "seu e-mail"}</strong><small>Confira também a caixa de spam.</small></div>
            <form className={styles.formulario} onSubmit={confirmar}>
                <VerificationCode value={codigo} onChange={setCodigo} />
                {erro && <p className={styles.erro}>{erro}</p>}
                <Button type="submit" fullWidth disabled={loading}>{loading ? "Validando..." : "Confirmar código"} <span className={styles.arrow}>→</span></Button>
                <Button variant="link" fullWidth onClick={() => navigate("/cadastro")}>Voltar para o cadastro</Button>
            </form>
        </AuthBox>
    );
}

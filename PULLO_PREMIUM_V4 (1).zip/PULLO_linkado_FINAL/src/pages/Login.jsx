import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import styles from "./Login.module.css";
import logo from "../assets/pullo-logo.png";
import hero from "../assets/pullo-login-hero.svg";

export default function Login() {
    const navigate = useNavigate();
    const location = useLocation();
    const [sucesso, setSucesso] = useState(location.state?.sucesso || "");
    const [email, setEmail] = useState("");
    const [senha, setSenha] = useState("");
    const [tipo, setTipo] = useState("CLIENTE");
    const [erro, setErro] = useState("");
    const [loading, setLoading] = useState(false);

    async function entrar(e) {
        e.preventDefault();
        setErro("");
        if (!email || !senha) {
            setErro("Preencha seu e-mail e sua senha.");
            return;
        }
        setLoading(true);
        try {
            const r = await fetch("http://localhost:5000/api/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, senha })
            });
            const d = await r.json();
            if (!r.ok) {
                setErro(d.error || "Não foi possível entrar.");
                return;
            }
            const u = { ...d.usuario, tipo: String(d.usuario?.tipo || "").trim().toUpperCase() };
            if (u.tipo !== tipo) {
                setErro(`Este acesso é de ${u.tipo}. Selecione o perfil correto.`);
                return;
            }
            localStorage.setItem("usuario", JSON.stringify(u));
            navigate(u.tipo === "ADM" ? "/admin" : u.tipo === "ENTREGADOR" ? "/entregador" : "/cliente");
        } catch {
            setErro("Não foi possível conectar ao servidor. Inicie o Flask na porta 5000.");
        } finally {
            setLoading(false);
        }
    }

    return (
        <main className={styles.page}>
            <section className={styles.visual}>
                <div className={styles.visualOverlay} />
                <div className={styles.visualHeader}>
                    <img src={logo} alt="PULLO" />
                    <div><strong>PULLO</strong><span>LOGISTICS</span></div>
                </div>
                <div className={styles.heroCopy}>
                    <span className={styles.kicker}>LOGÍSTICA INTELIGENTE</span>
                    <h1>Seu pedido.<br /><em>Nosso movimento.</em></h1>
                    <p>Uma plataforma criada para conectar clientes, entregadores e operações em uma experiência simples, rápida e profissional.</p>
                    <div className={styles.heroStats}>
                        <div><b>24/7</b><span>Operação conectada</span></div>
                        <div><b>1 painel</b><span>Para toda a operação</span></div>
                    </div>
                </div>
                <img className={styles.heroImage} src={hero} alt="Painel visual de operação logística da PULLO" />
                <div className={styles.liveBadge}><i /> Operação em tempo real <span>●</span></div>
            </section>

            <section className={styles.side}>
                <div className={styles.formBox}>
                    <div className={styles.mobileBrand}>
                        <img src={logo} alt="PULLO" />
                        <div><strong>PULLO</strong><span>LOGISTICS</span></div>
                    </div>
                    <div className={styles.formIntro}>
                        <span>ACESSO À PLATAFORMA</span>
                        <h2>Entrar na PULLO</h2>
                        <p>Use seus dados para acessar seu ambiente.</p>
                    </div>
                    <form onSubmit={entrar}>
                        <label className={styles.field}>E-mail
                            <div className={styles.inputWrap}><span>✉</span><input type="email" value={email} onChange={e => setEmail(e.target.value.toLowerCase().trim().slice(0, 120))} placeholder="voce@exemplo.com" autoComplete="email" /></div>
                        </label>
                        <label className={styles.field}>Senha
                            <div className={styles.inputWrap}><span>●</span><input type="password" value={senha} onChange={e => setSenha(e.target.value.slice(0, 72))} placeholder="Digite sua senha" autoComplete="current-password" /></div>
                        </label>
                        <label className={styles.field}>Perfil de acesso
                            <div className={styles.selectWrap}><span>◈</span><select value={tipo} onChange={e => setTipo(e.target.value)}><option value="CLIENTE">Cliente</option><option value="ENTREGADOR">Entregador</option><option value="ADM">Administrador</option></select><b>⌄</b></div>
                        </label>
                        {sucesso && <div className={styles.success}><strong>✓</strong><span>{sucesso}</span></div>}
                        {erro && <div className={styles.error}><strong>!</strong><span>{erro}</span></div>}
                        <button className={styles.primary} disabled={loading}>{loading ? "Entrando..." : "Entrar na plataforma"}<span>→</span></button>
                    </form>
                    <div className={styles.links}><button onClick={() => navigate("/cadastro")}>Criar minha conta</button><button onClick={() => navigate("/recuperar-senha")}>Esqueci minha senha</button></div>
                    <button className={styles.admin} onClick={() => navigate("/login-admin")}><span className={styles.adminIcon}>⌁</span><div><strong>Área administrativa</strong><small>Acesso exclusivo para gestão</small></div><b>→</b></button>
                    <footer>© 2026 PULLO · Plataforma de logística</footer>
                </div>
            </section>
        </main>
    );
}

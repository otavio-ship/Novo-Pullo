import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";
import styles from "./RecuperarSenha.module.css";

export default function RecuperarSenha() {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [erro, setErro] = useState("");
    const [loading, setLoading] = useState(false);

    async function continuar(e) {
        e.preventDefault(); setErro("");
        if (!email) { setErro("Digite seu e-mail para continuar."); return; }
        setLoading(true);
        try {
            const resposta = await fetch("http://localhost:5000/api/esqueceu_senha", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email}) });
            const dados = await resposta.json();
            if (!resposta.ok) { setErro(dados.error || "Erro ao solicitar recuperação."); return; }
            localStorage.setItem("email_recuperacao", email);
            navigate("/confirmar-recuperacao");
        } catch { setErro("Erro ao conectar com o servidor."); }
        finally { setLoading(false); }
    }

    return (
        <AuthBox titulo="Recuperar senha" subtitulo="Vamos enviar um código de segurança para você criar uma nova senha.">
            <div className={styles.steps}><span className={styles.active}>1</span><i /><span>2</span><i /><span>3</span></div>
            <form className={styles.formulario} onSubmit={continuar}>
                <label className={styles.label}>E-mail cadastrado
                    <Input type="email" placeholder="voce@exemplo.com" value={email} onChange={e=>setEmail(e.target.value)} />
                </label>
                {erro && <p className={styles.erro}>{erro}</p>}
                <Button type="submit" fullWidth disabled={loading}>{loading ? "Enviando..." : "Enviar código"}<span className={styles.arrow}>→</span></Button>
            </form>
            <Button variant="link" fullWidth onClick={() => navigate("/login")}>Voltar para login</Button>
        </AuthBox>
    );
}

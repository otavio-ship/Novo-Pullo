import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthBox from "../components/AuthBox/AuthBox";
import Button from "../components/Button/Button";
import VerificationCode from "../components/VerificationCode/VerificationCode";
import styles from "./ConfirmarRecuperacao.module.css";

export default function ConfirmarRecuperacao() {
    const navigate = useNavigate();
    const [codigo, setCodigo] = useState("");
    const [erro, setErro] = useState("");
    const [loading, setLoading] = useState(false);
    const email = localStorage.getItem("email_recuperacao");

    async function confirmar(e) {
        e.preventDefault();
        setErro("");
        if (!codigo || codigo.length !== 6) { setErro("Digite os 6 números do código recebido."); return; }
        if (!email) { setErro("E-mail não encontrado."); navigate("/recuperar-senha"); return; }
        setLoading(true);
        try {
            const resposta = await fetch("http://localhost:5000/api/confirmar_codigo_recuperacao", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email,codigo}) });
            const dados = await resposta.json();
            if (!resposta.ok) { setErro(dados.error || "Código inválido."); return; }
            navigate("/nova-senha");
        } catch { setErro("Erro ao conectar com o servidor."); }
        finally { setLoading(false); }
    }

    return (
        <AuthBox titulo="Confirmar código" subtitulo="Digite o código de segurança para continuar a recuperação.">
            <div className={styles.steps}><span className={styles.done}>✓</span><i /><span className={styles.active}>2</span><i /><span>3</span></div>
            <div className={styles.emailCard}><span>CÓDIGO DE RECUPERAÇÃO</span><strong>{email || "seu e-mail"}</strong><small>O código é válido somente para esta solicitação.</small></div>
            <form className={styles.formulario} onSubmit={confirmar}>
                <VerificationCode value={codigo} onChange={setCodigo} />
                {erro && <p className={styles.erro}>{erro}</p>}
                <Button type="submit" fullWidth disabled={loading}>{loading ? "Validando..." : "Continuar"}<span className={styles.arrow}>→</span></Button>
            </form>
            <Button variant="link" fullWidth onClick={() => navigate("/recuperar-senha")}>Voltar</Button>
        </AuthBox>
    );
}

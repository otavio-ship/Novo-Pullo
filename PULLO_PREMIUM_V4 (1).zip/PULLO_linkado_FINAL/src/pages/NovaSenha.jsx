import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";
import styles from "./NovaSenha.module.css";

export default function NovaSenha() {
    const navigate = useNavigate();
    const [novaSenha, setNovaSenha] = useState("");
    const [confirmar, setConfirmar] = useState("");
    const [erro, setErro] = useState("");
    const [loading, setLoading] = useState(false);
    const email = localStorage.getItem("email_recuperacao");

    async function alterarSenha(e) {
        e.preventDefault(); setErro("");
        if (!email) { setErro("E-mail não encontrado."); return; }
        if (!novaSenha || !confirmar) { setErro("Preencha todos os campos."); return; }
        if (novaSenha !== confirmar) { setErro("As senhas não são iguais."); return; }
        if (novaSenha.length < 6) { setErro("A senha deve ter pelo menos 6 caracteres."); return; }
        setLoading(true);
        try {
            const resposta = await fetch("http://localhost:5000/api/alterar_senha", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email,nova_senha:novaSenha,confirmar_senha:confirmar}) });
            const dados = await resposta.json();
            if (!resposta.ok) { setErro(dados.error || "Erro ao alterar senha."); return; }
            localStorage.removeItem("email_recuperacao");
            navigate("/login", { state: { sucesso: "Senha alterada com sucesso. Agora você já pode entrar." } });
        } catch { setErro("Não foi possível conectar com o servidor."); }
        finally { setLoading(false); }
    }

    return (
        <AuthBox titulo="Nova senha" subtitulo="Crie uma senha forte para proteger sua conta PULLO.">
            <div className={styles.steps}><span className={styles.done}>✓</span><i /><span className={styles.done}>✓</span><i /><span className={styles.active}>3</span></div>
            <form className={styles.formulario} onSubmit={alterarSenha}>
                <label className={styles.label}>Nova senha<Input type="password" placeholder="Mínimo de 6 caracteres" value={novaSenha} onChange={e=>setNovaSenha(e.target.value)} /></label>
                <label className={styles.label}>Confirmar nova senha<Input type="password" placeholder="Digite novamente" value={confirmar} onChange={e=>setConfirmar(e.target.value)} /></label>
                <div className={styles.security}><span>✓</span> Use pelo menos 6 caracteres e evite senhas fáceis.</div>
                {erro && <p className={styles.erro}>{erro}</p>}
                <Button type="submit" fullWidth disabled={loading}>{loading ? "Salvando..." : "Salvar nova senha"}<span className={styles.arrow}>→</span></Button>
            </form>
            <Button variant="link" fullWidth onClick={() => navigate("/login")}>Voltar para login</Button>
        </AuthBox>
    );
}

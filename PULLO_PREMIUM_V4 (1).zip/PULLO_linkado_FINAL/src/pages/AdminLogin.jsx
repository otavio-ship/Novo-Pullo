import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";
import styles from "./AdminLogin.module.css";

export default function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(false);

  async function entrar(e) {
    e.preventDefault(); setErro("");
    if (!email || !senha) { setErro("Preencha e-mail e senha."); return; }
    setCarregando(true);
    try {
      const resposta = await fetch("http://localhost:5000/api/login", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, senha })
      });
      const dados = await resposta.json();
      if (!resposta.ok) { setErro(dados.error || "Não foi possível entrar."); return; }
      const usuario = { ...dados.usuario, tipo: String(dados.usuario?.tipo || "").trim().toUpperCase() };
      if (usuario.tipo !== "ADM") { setErro("Este login é exclusivo para administradores."); return; }
      localStorage.setItem("usuario", JSON.stringify(usuario));
      navigate("/admin");
    } catch { setErro("Não foi possível conectar ao backend na porta 5000."); }
    finally { setCarregando(false); }
  }

  return <AuthBox titulo="Área Administrativa" subtitulo="Acesso protegido para gerenciamento da operação PULLO.">
    <div className={styles.cabecalho}><div className={styles.icone}>🔐</div><p>Entre com uma conta de administrador.</p></div>
    <form className={styles.formulario} onSubmit={entrar}>
      <Input type="email" placeholder="E-mail do administrador" value={email} onChange={e => setEmail(e.target.value.toLowerCase().trim().slice(0, 120))} />
      <Input type="password" placeholder="Senha" value={senha} onChange={e => setSenha(e.target.value.slice(0, 72))} />
      {erro && <p className={styles.erro}>{erro}</p>}
      <Button type="submit" fullWidth disabled={carregando}>{carregando ? "Entrando..." : "Entrar como administrador"}</Button>
    </form>
    <Button variant="link" fullWidth onClick={() => navigate("/login")}>Voltar para login</Button>
  </AuthBox>;
}

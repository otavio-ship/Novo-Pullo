import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import AdminLogin from "./pages/AdminLogin";
import Cadastro from "./pages/Cadastro";
import Confirmacao from "./pages/Confirmacao";
import RecuperarSenha from "./pages/RecuperarSenha";
import ConfirmarRecuperacao from "./pages/ConfirmarRecuperacao";
import NovaSenha from "./pages/NovaSenha";
import Cliente from "./pages/Cliente";
import Entregador from "./pages/Entregador";
import Admin from "./pages/Admin";

function Protegida({ usuario, tipo, children }) {
  if (!usuario) return <Navigate to="/login" replace />;
  if (String(usuario.tipo || "").toUpperCase() !== tipo) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<Login />} />
      <Route path="/login-admin" element={<AdminLogin />} />
      <Route path="/cadastro" element={<Cadastro />} />
      <Route path="/confirmacao" element={<Confirmacao />} />
      <Route path="/recuperar-senha" element={<RecuperarSenha />} />
      <Route path="/confirmar-recuperacao" element={<ConfirmarRecuperacao />} />
      <Route path="/nova-senha" element={<NovaSenha />} />
      <Route path="/cliente" element={<ClienteProtegido />} />
      <Route path="/entregador" element={<EntregadorProtegido />} />
      <Route path="/admin" element={<AdminProtegido />} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

function lerUsuario() {
  try { return JSON.parse(localStorage.getItem("usuario")) || null; }
  catch { return null; }
}

function ClienteProtegido() {
  const usuario = lerUsuario();
  return <Protegida usuario={usuario} tipo="CLIENTE"><Cliente usuario={usuario} sair={() => { localStorage.removeItem("usuario"); location.href = "/login"; }} /></Protegida>;
}

function EntregadorProtegido() {
  const usuario = lerUsuario();
  return <Protegida usuario={usuario} tipo="ENTREGADOR"><Entregador usuario={usuario} sair={() => { localStorage.removeItem("usuario"); location.href = "/login"; }} /></Protegida>;
}

function AdminProtegido() {
  const usuario = lerUsuario();
  return <Protegida usuario={usuario} tipo="ADM"><Admin usuario={usuario} sair={() => { localStorage.removeItem("usuario"); location.href = "/login-admin"; }} /></Protegida>;
}
